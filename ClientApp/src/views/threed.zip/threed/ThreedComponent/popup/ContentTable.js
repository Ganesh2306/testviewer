
import { useDebugValue, useEffect, useState, useLayoutEffect } from "react"
import Select from "react-select"
import { selectThemeColors } from "@utils"
import '@styles/react/libs/react-select/_react-select.scss'
import './../ThreedStyle.css'
import { Edit } from "react-feather"
/*import Example from "./MultiSelect"*/
import { Threedold, currentselected, setCurrentselected, UpdateThreedold, DelIndex, reset, setThreedold, emptyThreedold } from './Tableold'
import MultiSelectDropdown, { SelectOrg }  from "./MultiselectDropodown"

import {
  Table,
  FormGroup,
  Label,
  Input 
} from "reactstrap"

export const old = []

const DefaultGroups = ({ name, handelOnchange, identifiers, id, pid }) => {
  return (
    <>
    <tr><td><Input type='text' id='basicInput' placeholder='Mesh1' value={name} disabled /></td></tr>
    </>
  )
}

const NewGroups = ({ name, groupName, handelOnchange, identifiers, id, pid, productName }) => {
    return <>
        <tr><td><Input type='text' id='basicInput' placeholder='Mesh2' defaultValue={productName} onload={(text) => {
    handelOnchange({identifiers, id, text, pid})
  }} /></td></tr>
  </>
}

const GroupProducts = ({ productName, handelOnchange, identifiers, id, pid }) => {
  return <>
  <tr><td><Input type='text' id='basicInput' placeholder='Mesh3' onChange={(text) => {
    handelOnchange({identifiers, id, text, pid})
  }} 
  defaultValue={productName}  /></td></tr>
  </>
}

const Textures = ({groupColour, handelOnchange, identifiers, id, pid}) => {
  return <>
  <tr><td><Input type='text' id='basicInput' placeholder='texture' onChange={(text) => {
    handelOnchange({identifiers, id, text, pid})
  }} 
  defaultValue={groupColour}  /></td></tr>
  </>
}
// manisha
const useWindowSize = () => {
  const [windowSize, setWindowSize] = useState({ width: 0, height: 0 })

  const handleSize = () => {
    setWindowSize({
      width: window.innerWidth,
      height: window.innerHeight
    })
  }

  useLayoutEffect(() => {
    handleSize()

    window.addEventListener("resize", handleSize)

    return () => window.removeEventListener("resize", handleSize)
  }, [])
  return windowSize
}
// manisha
const MainRow = ({datard, id, PrOrList}) => {
  const [check, setcheck] = useState()
  //const [active, setactive] = useState(currentselected)
  const handelOnchange  = ({identifiers, id, text, pid}) => {
    text = text.target.value
    UpdateThreedold({identifiers, id, text, pid})
  }

  return <>
  <tr id={`mainRow-${id}`} style={{backgroundColor: currentselected.id === id ? `#f7f7f7` : ''}} onClick={() => {
    if (currentselected.id !== id) {
      setCurrentselected(id)
      //setactive(currentselected)
    }
  }}>
    <td>1</td>
          <td>
            <div className="d-flex flex-column text-center align-items-center">
                  <img src={datard.imageUrl} />
                  <span>{datard.td_threed_image_name}</span>
                  <div className="pt-50">
                      <label style={{ fontSize: '0.8rem' }}>Rename</label>
                      <Input type='text' id='basicInput' placeholder={datard.td_threed_image_name} defaultValue={datard.td_threed_image_name} className="text-align:center" />
                    </div>
                  </div>
              </td>
              <td>
              <MultiSelectDropdown PrOrList={PrOrList} />
              </td>
              <td>
                <table className="ContentInner">
                <img src={datard.imageUrl} />
                    {/* {
                        datard.td_Image_Configuration.map((e, k) => {
                        return <DefaultGroups pid={id} id={k} identifiers={`td_Group_Name`} 
                        handelOnchange={handelOnchange} name={e.td_Group_Name} />
                      })
                    } */}
                </table>
              </td>
              <td>
                <table className="ContentInner">
                    {
                        datard.td_Image_Configuration.map((e, k) => {
                        return <DefaultGroups pid={id} id={k} identifiers={`td_Group_Name`} 
                        handelOnchange={handelOnchange} name={e.td_Group_Name} />
                      })
                    }
                </table>
              </td>
              <td>
                <table className="ContentInner">
                  {
                    datard.td_Image_Configuration.map((e, k) => {    
                    return <NewGroups pid={id} id={k} identifiers={`td_Group_Display_Name`} 
                    productName={e.td_Group_Name}
                    handelOnchange={handelOnchange} groupName={e.td_Group_Display_Name} />
                  })
                  }
              </table>
              </td>
              <td>
                <table className="ContentInner">
                { datard.td_Image_Configuration.map((e, k) => { return <MultiSelectDropdown PrOrList = { PrOrList } /> }) }

                {/*{ datard.td_Image_Configuration.map((e, k) => {*/}
                 
                {/*    return <Example PrOrList={ PrOrList }/>*/}
                {/*       })*/}
                {/*       }*/}
                  {/* { datard.td_Image_Configuration.map((e, k) => {
                 
                  return <GroupProducts pid={id} id={k} identifiers={`td_Group_Product_Name`} 
                        handelOnchange={handelOnchange} 
                        productName={e.td_Group_Product_Name} />
                        })
                        } */}
              </table>
              </td>
              <td>
                  <table className="ContentInner">
                    {datard.td_Image_Configuration.map((e, k) => <Textures pid={id} id={k} identifiers={`td_Group_Colour`} 
                    handelOnchange={handelOnchange} 
                    groupColour={e.td_Group_Colour} />)}
                  </table>
              </td>
              <td>
              <SelectOrg PrOrList={PrOrList} />
              </td>
              <td style={{textAlign: 'center'}}><Input type='text' className='text-center'id='basicInput' />
              </td>
              <td>
              <div className='custom-control custom-checkbox'>
              <Input type='checkbox' id="xx" name="aa" className='custom-control-input '  value = {check}  onChange={(e) => {
                  setcheck((e) => !e)
                }}/>                  
                <label for="xx" className='custom-control-label' />
              </div>
              </td>
          </tr>
  </>

}


const ContentTable = (props) => {
   
  const [Thumb, setThumb] = useState([])
  const windowSize = useWindowSize()

  useEffect(() => {  
    setThumb(setThreedold(props.files ? props.files : []))
    }, [props.files])
  
  useEffect(() => {
    if (!props.modal) {
      reset()
    }
  
    return () => {}
  }, [props.modal])
  
  
  useEffect(() => {
    try {
      if (Threedold.length > 0) {
        setCurrentselected(currentselected.id, () => {
          DelIndex(currentselected.id, setThumb) 
        })
      } 
    } catch (error) {
      
    }

    return () => {
    }
  }, [props.reMoveid])

  useEffect(() => {
    if (Threedold.length > 0) {
    emptyThreedold(() => setThumb([]))
    }
    return () => {}
  }, [props.changeFile])
  
  return (
    <Table responsive className="text-center" id="threedTable">
      
 <thead id="main-thead">
<tr>
      <th>sr.no</th>
      <th>Model</th>
      <th>Product</th>
      <th>Group Pic</th>
      <th>Group Name</th>
      <th>New Group Name</th>
      <th>Group Product</th>
      <th>Texture</th>
      <th>Oranization Name</th>
      <th>Credits</th>  
      <th></th>   
 </tr>

</thead>
          <tbody style={{width :'({windowSize.width})px'}} width= {windowSize.width}>
            {
              //ToDOo :- Table body comp 
            }
              {
              props.files && Thumb.map((e, k) => <MainRow PrOrList={props.PrOrList} id={k} datard = {e} />)
              }

      </tbody>
    </Table>
  )
}

export default ContentTable