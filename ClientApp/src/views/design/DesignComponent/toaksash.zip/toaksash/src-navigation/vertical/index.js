import { Home, Mail, Menu, Briefcase, Grid, Circle } from 'react-feather'

export default [
  {
    id: 'home',
    title: 'Home',
    icon: <Home size={20} />,
    navLink: '/home'
  },
  {
    id: 'design',
    title: 'Designs',
    icon: <Grid size={20} />,
    navLink: '/design'
  },
  {
    id: 'collection',
    title: 'My Collection',
    icon: <Briefcase size={20} />,
    navLink: '/collection'
    },
    {
    id: 'favourite_page',
     title: 'Favourites',
     icon: <Briefcase size={20} />,
     navLink: '/wishlist'
    },
    {
    id: 'cart_page',
    title: 'Cart',
    icon: <Briefcase size={20} />,
    navLink: '/cart'
    },
    {
        id: 'order_page',
        title: 'Orders',
        icon: <Briefcase size={20} />,
        navLink: '/order'
    },
    {
        header: 'Setup'
    },
    {
        id: 'screen_dpi',
        title: 'Setup Screen DPI',
        icon: <Briefcase size={20} />,
        navLink: '/screensetup'
    },  
    {
        header: 'Other'
    },
    {
        id: 'viewer_help',
        title: 'Help',
        icon: <Briefcase size={20} />,
        navLink: '/help'
    },
    {
        id: 'profile_page',
        title: 'My Profile',
        icon: <Briefcase size={20} />,
        navLink: '/profile'
    },
    {
        id: 'ch_pass',
        title: 'Change Password',
        icon: <Briefcase size={20} />,
        navLink: '/passwordchange'
    },
    {
        id: 'logout',
        title: 'Logout',
        icon: <Briefcase size={20} />,
        navLink: '/logout'
    }
]
