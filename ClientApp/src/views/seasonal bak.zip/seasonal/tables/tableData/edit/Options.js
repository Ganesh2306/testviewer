//OrgOption
import { useState } from 'react'
import axios from 'axios'
import { getEditSeason, getCollectionList, CollezioniGetSeasonMastersList } from '../../../store/actions'
import { store } from '@store/storeConfig/store'
import { useDispatch } from 'react-redux'
import { MoreVertical, Trash2, Archive } from 'react-feather'
import { UncontrolledDropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap'
import Swal from 'sweetalert2'
import EditSeason from './EditSeason'
import EditCollection from './EditCollection'

export const SeasonalOptions = (props) => {
    const dispatch = useDispatch()
    const [isShow, setShow] = useState(false)
    const [isShow2, setShow2] = useState(false)   
    if (isShow) {
        return (
            <EditSeason id={props.ID} isShow={isShow} setShow={setShow}  buttonName='Edit' />
        )
     } 
    return (
    <UncontrolledDropdown>
    <DropdownToggle tag='div' className='btn btn-sm'>
            <MoreVertical size={14} className='cursor-pointer' />
        </DropdownToggle>
        <DropdownMenu right>
                    <DropdownItem  buttonName='Edit'
                                 className='w-100'
                                 onClick={() => {
                                     dispatch({
                                         type: 'GET_SEASON',
                                         selectedRole: null
                                     })
                                     setShow(true)
                                     const obj = new Object()
                                     obj.season_Id = props.ID
             
                                     store.dispatch(getEditSeason(obj))
             
                                 }}
                    
                    >
                        <Archive size={14} className='mr-50' />

                        <span className='align-middle'>Edit</span>                      
                    </DropdownItem>
                    <DropdownItem className='w-100' onClick={() => {
                
                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You want to delete this ?",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.isConfirmed) {

                            // const role = new Object()
                            // role.season_Id = props.ID
                            // role.state = 3
                            // role.is_Deleted = true
                            const obj = {
                                State: 3,
                                sm_Season_Id: props.ID
                            }
                            axios.post(`./Seasonal/CollezioniSaveSeasonMasters`, obj)
                                .then(response => {
                                    const Isave = JSON.parse(response.data) === null ? null : JSON.parse(response.data).isSave
                                    if (JSON.parse(response.data).message === null) {
                                        if (Isave !== null && Isave !== false) {
                                            Swal.fire(
                                                'Deleted!',
                                                'Season has been deleted.',
                                                'success'
                                            )
                                            const obj = new Object()
                                            const pageno = 0 //Number(document.getElementsByClassName("pagination")[0].getElementsByClassName("active")[0].innerText) - 1 //abhishek 03/03
                                            const entries = Number(document.getElementById("sort-select").value)
                                            if (pageno === 0) {
                                                obj.page = 0
                                                obj.perPage = entries
                                            } else {
                                                obj.page =  entries
                                                obj.perPage = pageno * entries
                                            }
                                            store.dispatch(CollezioniGetSeasonMastersList(obj))
                                        } else {
                                            Swal.fire({
                                                icon: 'error',
                                                title: 'Oops...',
                                                text: 'Something went wrong!'
                                            })
                                        }
                                    } else {
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Role',
                                            text: JSON.parse(response.data).message
                                        })
                                    }
                                })
                                .then(() => {

                                })
                                .catch(err => console.log(err))

                        }
                    })
                }}>
                    <Trash2 size={14} className='mr-50' />
                    <span className='align-middle'>Delete</span>
                  </DropdownItem>
        </DropdownMenu>
    </UncontrolledDropdown>
    )
 }
export const CollectionOptions = (props) => {
    const dispatch = useDispatch()
    const [isShow, setShow] = useState(false)
    const [isShow2, setShow2] = useState(false)   
    if (isShow2) {
        return (
            <EditCollection id={props.ID} isShow2={isShow2} setShow2={setShow2}  buttonName='Edit' />
        )
     } 
    return (
    <UncontrolledDropdown>
    <DropdownToggle tag='div' className='btn btn-sm'>
            <MoreVertical size={14} className='cursor-pointer' />
        </DropdownToggle>
        <DropdownMenu right>
                    <DropdownItem  buttonName='Edit'
                                 className='w-100'
                                 onClick={() => {
                                     dispatch({
                                         type: 'GET_SEASON',
                                         selectedRole: null
                                     })
                                     setShow2(true)
                                     const obj = new Object()
                                     obj.season_Id = props.ID
             
                                     store.dispatch(getEditSeason(obj))
             
                                 }}
                    
                    >
                        <Archive size={14} className='mr-50' />

                        <span className='align-middle'>Edit</span>                      
                    </DropdownItem>
                    <DropdownItem className='w-100' onClick={() => {
                
                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You want to delete this ?",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.isConfirmed) {

                            const role = new Object()
                            role.season_Id = props.ID
                            role.state = 3
                            role.is_Deleted = true
                            axios.post(`./Role/SaveRole`, role)
                                .then(response => {
                                    const Isave = JSON.parse(response.data) === null ? null : JSON.parse(response.data).isSave
                                    if (JSON.parse(response.data).message === null) {
                                        if (Isave !== null && Isave !== false) {
                                            Swal.fire(
                                                'Deleted!',
                                                'Role has been deleted.',
                                                'success'
                                            )
                                            const obj = new Object()
                                            const pageno = 0 //Number(document.getElementsByClassName("pagination")[0].getElementsByClassName("active")[0].innerText) - 1 //abhishek 03/03
                                            const entries = Number(document.getElementById("sort-select").value)
                                            if (pageno === 0) {
                                                obj.page = 0
                                                obj.perPage = entries
                                            } else {
                                                obj.page =  entries
                                                obj.perPage = pageno * entries
                                            }
                                            dispatch(getRolesData(obj))
                                        } else {
                                            Swal.fire({
                                                icon: 'error',
                                                title: 'Oops...',
                                                text: 'Something went wrong!'
                                            })
                                        }
                                    } else {
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Role',
                                            text: JSON.parse(response.data).message
                                        })
                                    }
                                })
                                .then(() => {

                                })
                                .catch(err => console.log(err))

                        }
                    })
                }}>
                    <Trash2 size={14} className='mr-50' />
                    <span className='align-middle'>Delete</span>
                  </DropdownItem>
        </DropdownMenu>
    </UncontrolledDropdown>
    )
 }
