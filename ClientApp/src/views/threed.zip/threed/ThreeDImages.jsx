// ** React Imports
import { Fragment, useState, useEffect, useRef } from 'react'
import axios from 'axios'

import TopBarOrg from './ThreedComponent/TopBarOrg'
import TopBarUser from './ThreedComponent/TopBarUser'
import ImgGrid from './ThreedComponent/ImgGrid'
// ** Styles
import '@styles/react/libs/tables/react-dataTable-component.scss'
// ** Styles
import '@styles/base/pages/app-ecommerce.scss'
import { error } from 'jquery'
import MultiSelectProduct from './ThreedComponent/MultiselectProduct'

const ThreeDImages =  () => {
  const [ImgViewToggle, setImgViewToggle] = useState(true)
  const [rerender, setrerender] = useState(false)
  const forceRerender = () => setrerender(!rerender)
  const [imgData, setimgData] = useState([])
    const [count, setCount] = useState()
    const [credit, setCredit] = useState()
    const [creditlimit, setcreditlimit] = useState()
    const [select, setSelect] = useState(false)
    const [isLoading, setLoading] = useState(true)
    const orgidref = useRef(null)
    const applicationref = useRef(null)
    const modelsref = useRef(null)
    const productsref = useRef(null)
    const txtsearchref = useRef(null)
    const designameref = useRef(null)
    const pagestartref = useRef(0)
    const pagendref = useRef(25)
    const newselctionref = useRef(0)
    const newcheckedref = useRef()
    const [activeView, setActiveView] = useState('grid')
    let PrOr = [null, null]
    const callme = async () => {
        PrOr[0] = await axios.get(`./ThreeD/GetProductList`)
        //const GetOrganisationList 
        PrOr[1] = await axios.get(`./ThreeD/GetOrganisationList`)
    }

    const [PrOrList, setPrOrList] = useState(null)

    const FilterList = (Data) => {
        if (Data === null || Data === undefined || Data instanceof Error || Data === false || Data === "") {
            return []
        }
        const getList = {}
        Data?.allOrgList.forEach((e) => {
            getList[e.organisation_id] = e.organization_Name
        })
        return getList
    }

    useEffect(async () => {
      try {
          //const getProductList 
          //await callme()
          axios.get(`./ThreeD/GetProductList`).then((productList) => {
            axios.get(`./ThreeD/GetOrganisationList`).then((orgList) => {
              
              setPrOrList({
                ProductList: JSON.parse(productList.data),
                OrgList:FilterList(orgList.data && JSON.parse(orgList.data))
            })
            setLoading(false)
            
            })

          }).catch((e) => {
            console.log(e)
          })

         /*  console.log({
            ProductList: PrOr[0] && JSON.parse(PrOr[0].data)
        }, 'from root') */
     
      } catch (error) {
          PrOr = [null, null]
      }
  }, [])

  if (isLoading) {
    return <div className="App">Loading...</div>
  }

  return (
    <Fragment>       
          <div className='main-design-div'>
              <TopBarOrg txtsearchref={txtsearchref} designameref={designameref} orgidref={orgidref} productsref={productsref} 
              modelsref={modelsref} applicationref={applicationref} setSelect={setSelect} PrOrList={PrOrList} 
              setimgData={setimgData} ImgViewToggle={ImgViewToggle} setImgViewToggle={setImgViewToggle} 
              forceRerender={forceRerender} rerender={rerender} count={count} credit={credit} creditlimit={creditlimit} 
              pagestartref={pagestartref} pagendref={pagendref} newselctionref={newselctionref} activeView = {activeView} setActiveView = {setActiveView}
              />

             
              {/*<TopBarUser  ImgViewToggle={ImgViewToggle} setImgViewToggle={setImgViewToggle} />*/}
              <ImgGrid txtsearchref={txtsearchref} designameref={designameref} orgidref={orgidref} productsref={productsref} 
              modelsref={modelsref} applicationref={applicationref} select={ select } PrOrList={PrOrList} 
              ImgViewToggle={ImgViewToggle} forceRerender={forceRerender} rerender={rerender} imgData={imgData} 
              setimgData={setimgData} setCount={setCount} setCredit={setCredit} setcreditlimit={setcreditlimit}
              credit={credit} creditlimit={creditlimit} pagestartref={pagestartref} pagendref={pagendref} count={count}
              newselctionref={newselctionref} newcheckedref={newcheckedref} activeView = {activeView} setActiveView = {setActiveView}
              />
      </div>
    </Fragment>
  )
}

export default ThreeDImages
