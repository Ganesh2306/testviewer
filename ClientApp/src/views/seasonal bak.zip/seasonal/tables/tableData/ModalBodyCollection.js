import { useState, useContext, forwardRef } from 'react'
import { Input, Label, Col, ModalBody, FormFeedback, Button } from 'reactstrap'
import "react-datepicker/dist/react-datepicker.css"
import { EditableSelect } from '../../FormComponent/SelectOption'
import './../../seasons.css'

// ! PopUpBody

const ModalBodyCollection = forwardRef((props, ref) => {
    const [articleValue, setArticleValue] = useState('')
    const onChangeArticleName = (e) => {
        setArticleValue(e.target.value)
    }
    return (
        < ModalBody >
            <Col className="row form-group ">

                <Label className="col-form-label col-sm-6">Season Name <span style={{ color: 'red' }}>*</span></Label>
                <div className="col-sm-6 p-0">
                <Input type="select" name="dbdrivepath" className=" col-sm-12" placeholder="Select Season" parentid="#C_StoreType" subid="#C_StoreType" id="C_StoreType"
                
                >
                     <option value="local" name="local">SS23</option> 
                     <option value="local" name="local">AW23</option> 
                </Input>
                 
                </div>
            </Col>
            <Col className="row form-group ">

                <Label className="col-form-label col-sm-6">Collection Name <span style={{ color: 'red' }}>*</span></Label>
                <div className="col-sm-6 p-0">
                    
                    <Input  
                         name="role_Name" autoComplete="off" type="text" className="form-control" id="role_Name" placeholder="Collection Name"
                     
                    />
                    
                </div>
            </Col>
            <Col className="row form-group ">

                <Label className="col-form-label col-sm-6">Collection Type <span style={{ color: 'red' }}>*</span></Label>
                <div className="col-sm-6 p-0">
                <Input type="select" name="dbdrivepath" className=" col-sm-12" placeholder="Select Season" parentid="#C_StoreType" subid="#C_StoreType" id="C_StoreType"
                
                >
                     <option value="local" name="local">Production</option> 
                     <option value="local" name="local">Development</option> 
                </Input>
                 
                </div>
            </Col>
            <Col className="row form-group article_section">

                <Label className="col-form-label col-sm-6">Article <span style={{ color: 'red' }}>*</span></Label>
                <div className="col-sm-6 p-0">
                  
                <EditableSelect onChangeArticle={onChangeArticleName} onFocusOut={onChangeArticleName} value={articleValue} />
              
                </div>
            </Col>
            <Col className="row form-group ">

                <Label className="col-form-label col-sm-6">Customer </Label>
                <div className="col-sm-6 p-0">
                <Input type="select" name="dbdrivepath" className=" col-sm-12" placeholder="Select Season" parentid="#C_StoreType" subid="#C_StoreType" id="C_StoreType"
                
                >
                     <option value="local" name="local">Raymond</option> 
                     <option value="local" name="local">Arvind Brand</option> 
                     <option value="local" name="local">Century</option> 
                     <option value="local" name="local">Morarjee</option> 
                     <option value="local" name="local">Getznar</option> 
                     <option value="local" name="local">Hugo Boss</option> 
                     <option value="local" name="local">Pradha</option> 
                     <option value="local" name="local">Angelico</option> 
                </Input>
                 
                </div>
            </Col>
            <Col className="row form-group ">

                <Label className="col-form-label col-sm-6">State <span style={{ color: 'red' }}>*</span></Label>
                <div className="col-sm-6 p-0">
                <Input type="select"  name="dbdrivepath" className=" col-sm-12" parentid="#C_StoreType" subid="#C_StoreType" id="C_StoreType"
                
                  >
                     <option value="local" name="local">Active</option> 
                     <option value="local" name="local">Block</option> 
                  </Input>
                        
                   
 </div>
            </Col>
            <Col className="row form-group ">

                <Label className="col-form-label col-sm-6">Picture <span style={{ color: 'red' }}></span></Label>
                <div className="col-sm-6 p-0">
               
                    <Input autoComplete="off" type="file"  style={{display:'Browse...'}} id="role_Id" 
                         name="role_Id" placeholder="Description"  />
                        {/* <Button >
                        Browse...
                        </Button> */}
                     <FormFeedback></FormFeedback>
                    
                </div>
            </Col>
    
        </ModalBody >
    )
})

export default ModalBodyCollection
