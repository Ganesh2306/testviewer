import React, { useState, useEffect } from "react"
import {
    Button,
    Modal,
    ModalHeader,
    ModalBody,
    ModalFooter,
    Form,
    Label,
    Col,
    Row,
    Input
} from "reactstrap"
import ContentTable, { old } from "./ContentTable"
import { connect } from 'react-redux'
import { setUploadFile } from '../redux/uploadFile/uploadFile.actions'
import UploadProgress from '../UploadProgress/UploadProgress'
import './../ThreedStyle.css'
import Example from "./MultiSelect"
import axios from 'axios'
import { Threedold, threeDImages as temp3d, currentselected, DelIndex, setCurrentselected, Push, priSave, saveThreedImage  } from './Tableold'
//import { swal } from 'sweetalert'

const Swal = require('sweetalert2')

export const getHead = () => {
    const arr = []
    try {
        const a = document.getElementById('main-thead').firstElementChild.cells
        for (let index = 2; index < a.length; index++) {
            //const element = array[index];
            arr.push(a[index].innerText)
        }
        return arr
    } catch (error) {
        return []
    }
}

const getAllDataFromTable = (index, nodeIndex) => {
    const input = [2, 3, 4, 5]
    if (input.includes(index)) {
        return document.querySelectorAll(`#row-${nodeIndex} td input`)[index - 2].value
    } else {
        return document.querySelectorAll(`#row-${nodeIndex} td`)[index].textContent
    }
}

//let f = true
const TopBody = (props) => {
    const modifyobj = {}
    const removeAll = () => {
        if (Threedold.length > 0) {
            props.setChangeFile(!props.changeFile)
        } else {
            alert("plz add some")
        }
    }

    const removebyId = () => {
        if (Threedold.length > 0) {
        currentselected.isDel = !currentselected.isDel
        props.setreMoveid(!props.reMoveid)
        } else {
            alert("plz add some")
        }
    }
  

    const [selectedName, setselectedName] = useState()

    return (
        <div className="col-lg-12">
            <div>
                <Col className="col-xl-4 col-lg-4 col-md-4 col-sm-12 float-left p-0 leftpanel">
                    <Form className="form-inline">
                        <div className="form-group float-left col-lg-12 col-md-12 col-sm-12 flex-lg-nowrap pl-0">
                         <Label for="saveFabLibrary" className="col-lg-12 pl-0 justify-content-left" style={{ justifyContent: 'Left' }}>
                         {props.subheadername} Upload 3d Images and Product Name                     
                        </Label>

                        </div>
                    </Form>
                </Col>
                <Col className="col-xl-8 col-lg-8 col-md-8 col-sm-12 float-left text-lg-right p-0 rightpanel">
                    <div className="form-group mb-0">
                    { props.topbarstate && <Label
                            className="btn btn-sm btn-primary waves-effect waves-light  mb-1"
                            style={{ marginRight: "4px" }}
                        >
                            <Input
                                id="importFabric"
                                type="file"
                                accept=".3dc,.3dp,.3dg"
                                multiple="true"
                                onChange={props.handleAttachFIle}
                                style={{ display: "none", padding: "0.486rem 0.5rem" }}
                            />
          Upload 3D
            </Label>}
            { props.topbarstate &&
                        <Button
                            type="button"
                            id="removeFabric"
                            className="btn btn-sm btn-light waves-effect waves-light  mb-1"
                            style={{ marginRight: "4px", padding: "0.486rem 0.5rem" }}
                            onClick={() => {
                                //pass id 
                                alert('Work-in-Progress')
                                removebyId(5)
                            }}
                        >
                            Remove
            </Button> }
            { props.topbarstate &&             
                        <Button
                            type="button"
                            id="removeAllFabric"
                            className="btn btn-sm btn-light waves-effect waves-light mb-1"
                            style={{ marginRight: "4px" }}
                            onClick={removeAll}
                        >
                            Remove All
            </Button>}
                        <Button
                            type="button"
                            id="saveAllFabric"
                            className="btn btn-sm btn-light waves-effect waves-light mb-1"
                            style={{ marginRight: "4px" }}
                             onClick={ () => {
                                priSave((el) => {
                                    saveThreedImage(el[0]).then(e => {
                                        const res = e.data ? JSON.parse(e.data) : false
                                        if (res) {
                                           if (res.isSave) {
                                               Swal.fire({
                                                title: 'success',
                                                text: '3D save successfully.',
                                                timer: 2000
                                            })
                                        }
                                    }
                                        //console.log(e)
                                    })
                                    /* el.forEach(e => {
                                        saveThreedImage(e)
                                    }) */
                                 })
                             }
                                //pass Upload Id 
                                 // props.uploadSingleFile(2)
                               //  props.onSaveConfiguration
                             }
                            
                        >
                            Save
            </Button>
            { props.topbarstate &&
                        <Button
                            type="button"
                            id="saveAllFabric"
                            className="btn btn-sm btn-light waves-effect waves-light mb-1"
                            style={{ marginRight: "4px" }}
                            onClick={props.handelOnclick}                     
                        >
                            Save All
            </Button>}

                    </div>
                </Col>
                <UploadProgress />
            </div>

        </div>
    )
}

export const ThreeD_Design = (props) => {   
    const { PrOrList } = props
    const [AllFiles, setFiles] = useState(null)
    const [option, setOption] = useState()
    const [rollData, setrollData] = useState(null)
    const [changeFile, setChangeFile] = useState(false)
    const [reMoveid, setreMoveid] = useState(true)
    const [tableData, setTableData] = useState([])
   

    //useEffect(async () => {
    //    /* const response = await axios.get(`./Role/GetRoleDesignConfigurationByRole?RoleId=${0}`)
    //    setrollData(response.data)
    //    f = true */
    //   
    //    //Abhishek 
    //            const getProductList = await axios.get(`./ThreeD/GetProductList`)
    //    //setCustomerList(getProductList.data.customerListDto)
    //    console.log(getProductList)

    //}, [])
    useEffect(async () => {

    }, tableData)
    const handleAttachFIle = async(e) => {

        const formPayload = new FormData()
        Array.prototype.forEach.call(e.target.files,  file => {
            formPayload.append(file.name, file)
        }) 

        //Upload3DImages
        const res = await axios.post('./ThreeD/Upload3DImages', formPayload)
        console.log(res)


        //ToDo: Axios Call
            //! do a sevice req from  axios and get responce
            //! After reaponce push it to state Var 
               
            const threeDImages = [
                    {       
                        imageUrl: "http://172.16.10.194//ThreedImages//Women_Long_Dress//Women_Long_Dressb.jpg",
                        td_threed_image_id: 306836985,
                        td_threed_image_name: "Women_Long_Dress",
                        td_Image_Configuration: [
                          {
                            td_Threed_Image_Configuration_Id: 4060703451,
                            td_Threed_Image_Id: 306836985,
                            td_Productname: null,
                            td_Group_Name: "WlDress",
                            td_Group_Display_Name: null,
                            td_Group_Colour: null,
                            td_Group_Product_Name: null,
                            td_Group_Order_No: 0,
                            td_Credit: 0,
                            td_images_org_configuration: null,
                            state: 0
                          },
                          {
                            td_Threed_Image_Configuration_Id: 4060703451,
                            td_Threed_Image_Id: 306836985,
                            td_Productname: null,
                            td_Group_Name: "WlDress",
                            td_Group_Display_Name: null,
                            td_Group_Colour: null,
                            td_Group_Product_Name: null,
                            td_Group_Order_No: 0,
                            td_Credit: 0,
                            td_images_org_configuration: null,
                            state: 0
                          },
                          {
                            td_Threed_Image_Configuration_Id: 4060703451,
                            td_Threed_Image_Id: 306836985,
                            td_Productname: null,
                            td_Group_Name: "WlDress",
                            td_Group_Display_Name: null,
                            td_Group_Colour: null,
                            td_Group_Product_Name: null,
                            td_Group_Order_No: 0,
                            td_Credit: 0,
                            td_images_org_configuration: null,
                            state: 0
                          }
                        ]
                        }
                    ]
                    // ! -> sm -- axios call
                    //Push(threeDImages[0], setFiles)

                  //response.data._RootThreeDImageConfig
                const tableData1 = []
                threeDImages.forEach(function (item, index) {
                    const defaultGroups = []
                    const newGroups = []
                    const groupProducts = []
                    const textures = []
                    item.td_Image_Configuration.forEach(function (tdGroup, gitemIndex) {
                        defaultGroups.push(<tr><td><Input type='text' id='basicInput' placeholder='Mesh1' value={tdGroup.td_Group_Name} disabled /></td></tr>)
                        newGroups.push(<tr><td><Input type='text' id='basicInput' placeholder='Mesh1' onChange={handelOnchange} defaultValue={tdGroup.td_Group_Display_Name} /></td></tr>)
                        groupProducts.push(<tr><td><Input type='text' id='basicInput' placeholder='Mesh1' onChange={handelOnchange} defaultValue={tdGroup.td_Group_Product_Name}  /></td></tr>)
                        textures.push(<tr><td><Input type='text' id='basicInput' placeholder='texture' onChange={handelOnchange} defaultValue={tdGroup.td_Group_Colour}  /></td></tr>)
                    })
                    
                    tableData1.push(
                        <tr>
                            <td>1</td>
                            <td>
                                <div className="d-flex flex-column text-center align-items-center">
                                    <img src={item.imageUrl} />
                                    <span>jacket_04.jpg</span>
                                    <div className="pt-1">
                                        <label style={{ fontSize: '0.8rem' }}>Rename</label>
                                        <Input type='text' id='basicInput' placeholder='Enter New Name' className="text-align:center" />
                                    </div>
                                </div>
                            </td>
                            <td>
                                <Example />
                            </td>
                            <td>
                            <table className="ContentInner">
                                {defaultGroups}
                                </table>
                            </td>
                            <td><table className="ContentInner">
                                {newGroups}
                            </table>
                            </td>
                            <td><table className="ContentInner">
                                {groupProducts}
                            </table>
                            </td>
                            <td>
                                <table className="ContentInner">
                                    {textures}
                                </table>
                            </td>
                            <td>
                                <Example />
                            </td>
                            <td><Input type='text' id='basicInput' />
                            </td>

                        </tr>
                    )
                })
                //setTableData(tableData1)
                setFiles(JSON.parse(res.data))
            }
       

    const handelOnclick = () => {
        const arr = getHead() //[1,2,3,4,5,] 
        const len = arr.length
        const temp_arr = []
        old.map((e, k) => {
            const obj = { file: e.file }
            for (let i = 0; i < len; i++) {
                obj[arr[i]] = getAllDataFromTable(i + 2, k)
            }
            temp_arr.push(obj)
        })
        props.setUploadFile(temp_arr)
    }
    const handelOnchange = () => {
        
    }
    const uploadSingleFile = (id) => {
        const arr = getHead() //[1,2,3,4,5,] 
        const len = arr.length
        const temp_arr = []
        const obj = { file: old[id].file }
        for (let i = 0; i < len; i++) {
            obj[arr[i]] = getAllDataFromTable(i + 2, id)
        }
        temp_arr.push(obj)
        props.setUploadFile(temp_arr)

    }

    const onSaveConfiguration = (e) => {

      
        e.preventDefault()
        const selection = document.getElementById('collection3DLibrary').value
        let msg = ""
        switch (selection) {
            case 'Showroom':
                msg = selection
                break
            default:
                msg = "XML"
        }
        alert(msg)
        return

        const _RoleAssignment = new Object()
        _RoleAssignment.user_Id = document.getElementById('CAC_custName').getAttribute('uid')

        _RoleAssignment.is_Role_Admin = true
        _RoleAssignment.role_assignment_id = document.getElementById('CAC_custName').getAttribute('raid') === null ? 0 : document.getElementById('CAC_custName').getAttribute('raid')
        const selectedRoleID = document.getElementById('CAC_accessRole').selectedOptions[0].getAttribute('roleid')
        if (Number(selectedRoleID) === 0) {
            _RoleAssignment.state = 3
        } else {
            _RoleAssignment.state = document.getElementById('CAC_custName').getAttribute('raid') === null ? 0 : 2
        }
        _RoleAssignment.role_Id = selectedRoleID
        //dispatch(addCustUser(custuser))
        axios.post(`./Role/SaveRoleAssignments`, _RoleAssignment)
            .then(response => {

                const Isave = response.data === null ? null : JSON.parse(response.data).isSave
                if (Isave !== null && Isave !== false) {
                    //const custuser = new Object()
                    // custuser.customer_Id = response.data.req.org_type_id
                    // dispatch(getCustomerUsers(custuser))
                    //dispatch(getData())
                    const obj = new Object()
                    obj.page = 0
                    obj.perPage = 7
                    dispatch(getData(obj))

                    setis_open(false)
                    Swal.fire(
                        'Success!',
                        'Role assigned successfully!!',
                        'success'
                    )
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'Something went wrong!'
                    })
                }

            })
            .then(() => {

            })
            .catch(err => console.log(err))
        // console.log(Customer)
    }

    return (
        <div>
            <Modal
                isOpen={props.modal}
                toggle={props.toggle}
                className="add_threedesign modal-xl shadow-none"
                style={{
                    width: "100%",
                    margin: "0",
                    maxWidth: "100%",
                    height: "100vh",
                    background: "#fff",
                    overflow: "hidden"
                }}
            >
                <ModalHeader toggle={props.toggle} >{props.headername}</ModalHeader>
                <Form>
                    <ModalBody className="px-0">
                        {
                            //**TopBody or TopBar */
                        }
                        <TopBody setUploadFile={props.setUploadFile}
                            onSaveConfiguration={onSaveConfiguration}
                            handleAttachFIle={handleAttachFIle}
                            handelOnclick={handelOnclick}
                            uploadSingleFile={uploadSingleFile}
                            changeFile={changeFile}
                            setChangeFile={setChangeFile}
                            rollData={rollData}
                            setreMoveid={setreMoveid}
                            reMoveid={reMoveid}
                            setOption={setOption} 
                            topbarstate={props.topbarstate}
                            />

                        <ContentTable files={AllFiles}
                            PrOrList={PrOrList}
                            rollData={rollData}
                            tableData={tableData}
                            changeFile={changeFile}
                            reMoveid={reMoveid}
                            option={option}
                            modal={props.modal}
                        />
                        {/* <Table /> */}
                    </ModalBody>
                </Form>
                <br />

            </Modal>
        </div>
    )
}

const mapDispatchToProps = dispatch => ({
    setUploadFile: files => dispatch(setUploadFile(files))
})

export default connect(null, mapDispatchToProps)(ThreeD_Design)
