﻿import React, { useState } from 'react'
import { Edit, Shield, HelpCircle } from 'react-feather'
import "react-datepicker/dist/react-datepicker.css"
import DatePicker from "react-datepicker"
import Avatar from '@components/avatar'
import avatarImg from '@src/assets/images/portrait/small/avatar-s-20.jpg'

import { FormGroup, Input, Label, Col, Modal, Button, ModalHeader, ModalBody, ModalFooter, Row, DropdownItem, Form, CustomInput, Media } from 'reactstrap'
import InputPasswordToggle from '@components/input-password-toggle'

export const MyProfile = (props) => {
    const [img, setImg] = useState(null)

    /*    const [cpmOpen, setCpm] = useState(false)*/
    return (
        <div>

            <Modal isOpen={props.profileOpen} toggle={() => props.setprofileOpen(false)} className='modal-md modal-dialog-centered' backdrop='static' >
                <ModalHeader toggle={() => props.setprofileOpen(false)}> My Profile</ModalHeader>

                <ModalBody>                
                        <Form>
                            <FormGroup row>
                                <Label sm='4' for='name'>
                                    First Name 
                                </Label>
                                <Col sm='8'>
                                    <Input type='text' name='name' id='name' placeholder='First Name' />
                                </Col>
                            </FormGroup>
                           
                            <FormGroup row>
                                <Label sm='4' for='lastname'>
                                Last Name <span style={{ color: 'red' }}>*</span>
                                </Label>
                                <Col sm='8'>
                                    <Input type='text' name='lastname' id='lastname_b' placeholder='Last Name' />
                                </Col>
                        </FormGroup>
                        <FormGroup row>
                            <Label sm='4' for='Userid'>
                                User Id <span style={{ color: 'red' }}>*</span>
                            </Label>
                            <Col sm='8'>
                                <Input type='text' name='userid' id='userid' placeholder='User ID' />
                            </Col>
                        </FormGroup>
                        <FormGroup row>
                            <Label sm='4' for='Email'>
                                Email <span style={{ color: 'red' }}>*</span>
                            </Label>
                            <Col sm='8'>
                                <Input type='email' name='Email' id='Email' placeholder='Email' />
                            </Col>
                        </FormGroup>

                            <FormGroup row>
                                <Label sm='4' for='mobile'>
                                Mobile <span style={{ color: 'red' }}>*</span>
                                </Label>
                                <Col sm='8'>
                                    <Input type='number' name='mobile' id='mobile' placeholder='Mobile' />
                                </Col>
                            </FormGroup>
                         
                        <FormGroup row>
                            <Label sm='4' for='profile'>
                                Profile Picture <span style={{color:'red'}}>*</span>
                            </Label>
                            <Col sm='8'>
                                <Avatar color='light-primary rounded-0' content='Peter Ingraham' initials size={180} style={{ width: '80px', height: '80px' }} />
                                <Button color='primary' className="ml-2" >
                                    Change
                                </Button>
                            </Col>
                        </FormGroup>
                            
                        </Form>
                  
                </ModalBody>
                <ModalFooter>
                    <Button color='primary' onClick={() => props.setprofileOpen(false)}>
                        Update
                    </Button>
                </ModalFooter>
            </Modal>
        </div>
    )
}    