
import { Coffee, ChevronLeft } from 'react-feather'

import { Row, Col, CardTitle, CardText, Form, FormGroup, Label, Input, CustomInput, Button } from 'reactstrap'
import '@styles/base/pages/page-auth.scss'


const ForgetView = (props) => {
    return (
        <div className='d-flex align-items-center auth-bg auth-viewer'>
          <div className='mx-auto text-xl-center'>
          <img class="login-logo-viewer text-lg-center mb-1" src="../../design_archive_logo.png" alt="Logo"/>
            <CardTitle tag='h3' className='font-weight-bold mb-1 text-lg-left login-header'>
              Forgot Password? 
            </CardTitle>
            <CardText className='mb-2 text-lg-left'>
              Enter your email and we'll send you instructions to reset your password
            </CardText>
            <Form className='auth-forgot-password-form mt-2' onSubmit={e => e.preventDefault()}>
              <FormGroup className='text-lg-left'>
                <Label className='form-label login-norm-text' for='login-email'>
                  Email
                </Label>
                <Input type='email' id='login-email' placeholder='john@example.com' autoFocus />
              </FormGroup>
              <Button.Ripple color='primary' block>
                Send reset link
              </Button.Ripple>
            </Form>
            <p className='text-center mt-2'>              
                <ChevronLeft className='mr-25' size={14} />
                <span className='align-middle' onClick={ () => { props.setforget(true) }}>Back to login</span>              
            </p>
          </div>
        </div>
    )
  }
  export default ForgetView