// ** React Imports
import { useState, useEffect } from 'react'
import { CollectionTableColumns, CollectionData } from '../seasondata'
import { Card, CardHeader, CardTitle, Input, Label, Row, Col } from 'reactstrap'
import Addcollection from '../../Addcollection'
import DataTable from 'react-data-table-component'
import { getData } from '../../store/actions'
import { useSelector, useDispatch } from 'react-redux'
import ReactPaginate from 'react-paginate'
const TableCollection = () => {
// ** Store Vars
const dispatch = useDispatch()
const store = useSelector(state => state.dataTables)

// ** States
const [currentPage, setCurrentPage] = useState(1)
const [rowsPerPage, setRowsPerPage] = useState(7)
const [searchValue, setSearchValue] = useState('')
const [clearbt, setClearbt] = useState(false)

  useEffect(() => {
    dispatch(
      getData({
        page: currentPage,
        perPage: rowsPerPage,
        q: searchValue
      })
    )
  }, [dispatch])

  // ** Function to handle filter
  const handleFilter = e => {
    setSearchValue(e.target.value)
    setClearbt(true)

    dispatch(
      getData({
        page: currentPage,
        perPage: rowsPerPage,
        q: e.target.value
      })
    )
  }

const resetInputField = e => {
            setSearchValue("")
            setClearbt(false)
 }
  // ** Function to handle Pagination and get data
  const handlePagination = page => {
    dispatch(
      getData({
        page: page.selected + 1,
        perPage: rowsPerPage,
        q: searchValue
      })
    )
    setCurrentPage(page.selected + 1)
  }

  // ** Function to handle per page
  const handlePerPage = e => {
    dispatch(
      getData({
        page: currentPage,
        perPage: parseInt(e.target.value),
        q: searchValue
      })
    )
    setRowsPerPage(parseInt(e.target.value))
  }

  // ** Custom Pagination
  const CustomPagination = () => {
    //const count = Number((store.total / rowsPerPage).toFixed(0))
    const count = 12

    return (
      <ReactPaginate
        previousLabel={''}
        nextLabel={''}
        breakLabel='...'
        pageCount={count || 1}
        marginPagesDisplayed={2}
        pageRangeDisplayed={2}
        activeClassName='active'
        forcePage={currentPage !== 0 ? currentPage - 1 : 0}
        onPageChange={page => handlePagination(page)}
        pageClassName={'page-item'}
        nextLinkClassName={'page-link'}
        nextClassName={'page-item next'}
        previousClassName={'page-item prev'}
        previousLinkClassName={'page-link'}
        pageLinkClassName={'page-link'}
        breakClassName='page-item'
        breakLinkClassName='page-link'
        containerClassName={
          'pagination react-paginate separated-pagination pagination-sm justify-content-end pr-1 mt-1'
        }
      />
    )
  }

  // ** Table data to render
  const dataToRender = () => {
    const filters = {
      q: searchValue
    }

    const isFiltered = Object.keys(filters).some(function (k) {
      return filters[k].length > 0
    })

    if (store.data.length > 0) {
      return store.data
    } else if (store.data.length === 0 && isFiltered) {
      return []
    } else {
      return store.allData.slice(0, rowsPerPage)
    }
  }
  return (
    <Card>
         <Row className='mx-0 my-1'> 
                <Col sm="3" md='4' className='pr-0 col-md-4'>
                  <div className='align-items-center col-sm-12 col-lg-12 d-inline-flex pr-0 pl-0'>
                      <Label className="col-form-label col-lg-3 pl-0">Seasons</Label>
                      <Input type="select" name="OrderCName" className="states order-alpha form-control state col-lg-6" parentid="#" subid="#" id="">
                          <option value="none">Select</option>
                          <option value="CustB" name="collection_a">Collection_a</option>
                          <option value="CustC" name="collection_b">Collection_b</option>
                          <option value="CustD" name="collection_c">Collection_c</option>
                      </Input>
                      <Addcollection />
                  </div>
                  
              </Col>       
          
              <Col sm='9' md='8' className='d-flex justify-content-end'>
                    <div className='d-flex align-items-center mb-sm-0 mr-1'>
                        <Label className='mr-1' for='search-input'>
                            Search
                        </Label>
                        <div class="input-icons" style={{ position: 'relative' }}>
                        <Input
                            className='dataTable-filter'
                            type='text'                              
                            id='search-input'
                            value={searchValue}
                            onChange={handleFilter}
                            /> 
                              {clearbt ? <i className="fa fa-times" aria-hidden="true" role='button' onClick={resetInputField} style={{ position: 'absolute', right: '2rem', top: '0.875rem' }}></i> : null}                          
                         </div>
                    </div>
                    <div className='d-flex align-items-center pl-0'>
                        <Label for='sort-select'>Show</Label>
                        <Input
                            className='dataTable-select'
                            type='select'
                            id='sort-select'                         
                            onChange={e => handlePerPage(e)}
                        >
                            <option value={7}>7</option>
                            <option value={10}>10</option>
                            <option value={25}>25</option>
                            <option value={50}>50</option>
                            <option value={75}>75</option>
                            <option value={100}>100</option>
                        </Input>
                    
                    </div>
                </Col> 
            </Row>
               <DataTable
                    noHeader
                    pagination
                    paginationServer
                    className='react-dataTable'
                    columns={CollectionTableColumns}    
                    paginationComponent={CustomPagination}
                    data={CollectionData}                  
                />  
            </Card>
  )
}

export default TableCollection