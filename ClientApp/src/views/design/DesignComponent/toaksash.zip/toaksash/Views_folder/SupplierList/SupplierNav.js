﻿import { useEffect, useState } from 'react'
import { Link } from "react-router-dom"

// ** Custom Components
import Avatar from '@components/avatar'

// ** Configs
import themeConfig from '@configs/themeConfig'

import { ModelPasswordChange } from '../../@core/layouts/components/NavbarPopup/ModalPasswordChange'
import { SuccessPasswordChange } from '../../@core/layouts/components/NavbarPopup//SuccessPasswordChange'
import { ScreenDpi } from '../../@core/layouts/components/NavbarPopup/ScreenDpi'
import { MyProfile } from  '../../@core/layouts/components/NavbarPopup/MyProfile'

// ** Third Party Components
import { UncontrolledDropdown, DropdownMenu, DropdownToggle, DropdownItem, Navbar, NavLink } from 'reactstrap'
import { User, Mail, CheckSquare, MessageSquare, Settings, CreditCard, HelpCircle, Power } from 'react-feather'
// ** Default Avatar Image
import defaultAvatar from '@src/assets/images/portrait/small/avatar-s-11.jpg'

export const SupplierNav = () => {
    const [cpmOpen, setCpm] = useState(false)
    const [successPassword, setsuccessPassword] = useState(false)

    const [profileOpen, setprofileOpen] = useState(false)
    const [dpiOpen, setdpiOpen] = useState(false)
    return (      
            <Link>
            <Navbar expand='lg' className='header-navbar navbar-fixed align-items-center navbar-shadow navbar-brand-center'>
                <NavLink to='' className="d-flex" >
                    <span className='brand-logo'>
                        <img src={themeConfig.parentapp.parentLogoImage} alt='logo' style={{ width: '30px', top: '-3px', position: 'relative' }} />
                    </span>
                  <span>
                  Textronics
                   </span>
                </NavLink>
                <div className='navbar-container d-flex justify-content-end'>
                <div className="text-right text-white float-right">
                        <ul className='nav navbar-nav align-items-center ml-auto'>

                            <UncontrolledDropdown tag='li' className='dropdown-user nav-item'>
                           
                                <DropdownToggle href='/' tag='a' className='nav-link dropdown-user-link'>              
                                            <Avatar img={defaultAvatar} imgHeight='40' imgWidth='40' status='online' />
                                </DropdownToggle>
                                <DropdownMenu right>
                                    <DropdownItem onClick={() => setdpiOpen(true)}>
                                        <Settings size={14} className='mr-75' />
                                        <span className='align-middle'>Setup Screen DPI</span>
                                    </DropdownItem>
                                    <ScreenDpi dpiOpen={dpiOpen} setdpiOpen={setdpiOpen} />
                                    <span><hr /></span>
                                    <DropdownItem>
                                      <CreditCard size={14} className='mr-75' />
                                        <span className='align-middle' onClick={() => setprofileOpen(true)}>Profile</span>
                                     </DropdownItem>
                                     <DropdownItem>
                                                <HelpCircle size={14} className='mr-75' />
                                                <span className='align-middle'>Help</span>
                                    </DropdownItem>
                                    <MyProfile profileOpen={profileOpen} setprofileOpen={setprofileOpen} />
                                    <DropdownItem >
                                      <HelpCircle size={14} className='mr-75' />
                                        <span className='align-middle' onClick={() => setCpm(true)}>Change Password</span>
                                    </DropdownItem>
                                    <ModelPasswordChange cpmOpen={cpmOpen} setCpm={setCpm} setsuccessPassword={setsuccessPassword}/>
                                    <SuccessPasswordChange successPassword={successPassword} setsuccessPassword={setsuccessPassword} />

                                    <DropdownItem tag={Link} to='/login'>
                                        <Power size={14} className='mr-75' />
                                        <span className='align-middle'>Logout</span>
                                    </DropdownItem>
                                </DropdownMenu>
                            </UncontrolledDropdown>
                        </ul>
                    </div>
                    </div>
                </Navbar>
            </Link>
      
    )
}