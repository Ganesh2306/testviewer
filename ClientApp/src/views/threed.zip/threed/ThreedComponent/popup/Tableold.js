import axios from "axios"

const ImageConfiguration = `td_Image_Configuration`

export const threeDImages = [
    {       
        imageUrl: "http://172.16.10.194//ThreedImages//Women_Long_Dress//Women_Long_Dressb.jpg",
        td_threed_image_id: 306836985,
        td_threed_image_name: "Women_Long_Dress",
        td_Image_Configuration: [
          {
            td_Threed_Image_Configuration_Id: 4060703451,
            td_Threed_Image_Id: 306836985,
            td_Productname: null,
            td_Group_Name: "WlDress",
            td_Group_Display_Name: null,
            td_Group_Colour: null,
            td_Group_Product_Name: null,
            td_Group_Order_No: 0,
            td_Credit: 0,
            td_images_org_configuration: null,
            state: 0
          },
          {
            td_Threed_Image_Configuration_Id: 4060703451,
            td_Threed_Image_Id: 306836985,
            td_Productname: null,
            td_Group_Name: "WlDress",
            td_Group_Display_Name: null,
            td_Group_Colour: null,
            td_Group_Product_Name: null,
            td_Group_Order_No: 0,
            td_Credit: 0,
            td_images_org_configuration: null,
            state: 0
          },
          {
            td_Threed_Image_Configuration_Id: 4060703451,
            td_Threed_Image_Id: 306836985,
            td_Productname: null,
            td_Group_Name: "WlDress",
            td_Group_Display_Name: null,
            td_Group_Colour: null,
            td_Group_Product_Name: null,
            td_Group_Order_No: 0,
            td_Credit: 0,
            td_images_org_configuration: null,
            state: 0
          }
        ]
        }
    ]

export let Threedold = [] 
window.getThr = () => Threedold

export const currentselected = {id: null,
                                isDel: false}
window.getCur = currentselected

export const emptyThreedold = (cb) => {
    Threedold = []
    currentselected.id = 0
    if (cb) {
        cb()
    }
}

export const reset = () => {
    Threedold = []
    currentselected.id = 0
    currentselected.isDel = false
}

export const setThreedold = (a, cb) => {
    Threedold = [...Threedold, ...a]
    if (cb) {
        cb()
    }
    return Threedold
}

export const UpdateThreedold = ({identifiers, id, text, pid, cb = null}) => {
    Threedold[pid][ImageConfiguration][id][identifiers] = text
    if (cb) {
        cb()
    }
}

export const DelIndex = (a, cb = null) => {
    Threedold = Threedold.filter((e, ind) => {
        return ind !== a
    })
    if (cb) {
        cb(Threedold)
    }
}

export const Push = (a, cb = null) => {
    Threedold.push(a)
    if (cb) {
        cb(Threedold)
    }
}

export const setCurrentselected = (a, cb = null) => {
    try {
        document.getElementById(`mainRow-${currentselected.id}`).style.backgroundColor = ''        
    } catch (error) {
        
    }

    currentselected.id = a
    document.getElementById(`mainRow-${currentselected.id}`).style.backgroundColor = '#f7f7f7'
    if (cb) {
        cb(a, currentselected)
    }
}

//ToDo:----------------------------------------------Save Image ----------------------------------------------//

/* [
    {
      "state": 0,
      "td_Threed_Image_Configuration_Id": 0,
      "td_Threed_Image_Id": 0,
      "td_Productname": "string",
      "td_Group_Name": "string",
      "td_Group_Display_Name": "string",
      "td_Group_Colour": "string",
      "td_Group_Product_Name": "string",
      "td_Group_Order_No": 0,
      "threedImageOrgConfiguration": "string",
      "td_Credit": 0,
      "saveThreedImageOrgConfiguratioRequestDto": [
        {
          "td_images_org_configuration_id": 0,
          "td_threed_Image_Id": 0,
          "td_Organisation_Id": 0
        }
      ]
    }
  ] */
// for 3d image save  send deta 
export const priSave = (cb = null) => {
   
    if (Threedold.length > 0) {
        const Totalarr = []
        Threedold.forEach((f) => {
          const  arr = f.td_Image_Configuration.map((e) => {
                e.state = 2
                e.threedImageOrgConfiguration = ""
                e.saveThreedImageOrgConfiguratioRequestDto = [
                    {
                    //td_images_org_configuration_id : 0,
                    td_Threed_Image_Id : e.td_Threed_Image_Id,
                    td_Organisation_Id : 0
                }
            ]
                return e
            })
            Totalarr.push(arr)
        })
        if (cb) {
            //! use arr flat methord with depth 1
            return cb(Totalarr)
        }
    } else {
        //return 
    }
}

window.getSave = priSave

export const saveThreedImage = async (_Data, cb) => {
    return axios.post(`./ThreeD/TdSaveImageConfigurations`, _Data)
    //await axios.post(`URL`, )
   //await axios.post(`./ThreeD/SaveTdImages`, _Data)
}/* 
priSave((el) => {
    saveThreedImage(el).then(e => {
        console.log(e.data)
    })
}).then(e => {

}).catch((e) => {

}) */