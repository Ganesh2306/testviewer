import React, { useState } from "react"
import {
  Button,
  Modal,
  ModalBody
} from "reactstrap"
import { AlertCircle } from "react-feather"
import axios from 'axios'
import Swal from "sweetalert2"


const CanCelPopUp = (props) => {
    return (
        <Modal isOpen={props.Cancel} toggle={props.CancelToogle} className="modal-md mt-4">
                <center ><h1 style={{marginTop:'20px', marginBottom:'5px'}} >Your Design is Safe</h1>
                 </center>
                <ModalBody>
                    <center>
                        <Button color="success" onClick={props.CancelToogle}>
                            OK
                        </Button>
                    </center>
                    
                           
          </ModalBody>

      </Modal>
    )
}


export const DeletePopUp = (props) => {

    const [Cancel, setCancel] = useState(false)
    return (
        <>
            <Modal isOpen={props.modal} toggle={props.toggle} className="modal-md">
                
                <center >
                <AlertCircle color='orange' size={100} style={{marginTop:'20px', marginBottom:'5px'}} /> <br />
                    <h1>Are You Sure?</h1>
                <br />
                <h5>Designs of this User will be permanently deleted!</h5>
                 </center>
                <ModalBody>
                    <div className='float-right'>
           
                <Button color="danger" onClick={() => {
                props.toggle()
                Swal.fire({
                    position: 'center',
                    icon: 'info',
                    title: 'Your Design is Safe'
                })
                }}>
                Cancel
                </Button>       
                <Button color="success" className='m-1' onClick={() => {
                    axios.post(`./ThreeD/TdSaveImageConfigurations`, props.delobj).then(() => {
                        setCancel(true)
                        props.toggle()
                        Swal.fire({
                            position: 'center',
                            icon: 'info',
                            title: 'Design Deleted Sucessfully..!'
                        })
                        props.forceRerender()
                       
                    })
                }}>
                Yes, delete it!
                </Button>     
                </div>           
          </ModalBody>

      </Modal>
      
       {/* <CanCelPopUp Cancel={ Cancel } CancelToogle={ () => {
          setCancel(false)
      }} /> */}
      
        </>
    )
}