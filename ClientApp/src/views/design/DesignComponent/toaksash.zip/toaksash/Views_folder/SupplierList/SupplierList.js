﻿import { useHistory } from 'react-router-dom'
import Select from 'react-select'
import { selectThemeColors } from '@utils'
import { Logo } from "../BrandingPage/brandingComponent/Logo"
import { SupplierNav } from "../SupplierList/SupplierNav"
import background from "../../assets/images/pages/brand/branding.jpg"
import '../BrandingPage/brandingComponent/branding.css'
import { Row, Media, Card } from 'reactstrap'


import mediaImg1 from '@src/assets/images/portrait/small/avatar-s-4.jpg'
import mediaImg2 from '@src/assets/images/portrait/small/avatar-s-1.jpg'
import mediaImg3 from '@src/assets/images/portrait/small/avatar-s-16.jpg'

const colourOptions = [
    { value: 'abc', label: 'abc' },
    { value: 'pqr', label: 'pqr' },
    { value: 'test2', label: 'test2'},
    { value: 'xyz', label: 'xyz' }
]

const SupplierList = () => {
    const history = useHistory()
    return (

        <div style={{ backgroundImage: `url(${background})` }} className="mybg" >
        <div className="pinkbg">
            <SupplierNav/>      
                <div className="grandparent">                    
                    <div className="parent">
                        <div className="my-2">
                            <svg x="0px" y="0px" viewBox="0 0 1000 1000" enable-background="new 0 0 1000 1000" height={100} fill="#000" >
                                <g><path fill="#000" d="M500,10C229.4,10,10,229.4,10,500c0,270.6,219.4,490,490,490c270.6,0,490-219.4,490-490C990,229.4,770.6,10,500,10z M500,952.1C250.3,952.1,47.9,749.7,47.9,500C47.9,250.3,250.3,47.9,500,47.9c249.7,0,452.1,202.4,452.1,452.1C952.1,749.7,749.7,952.1,500,952.1z" /><path d="M597,248.1v503.8h182.9V248.1H597z M728.3,625.4h-80.1v-63.3h80.1V625.4z M728.3,498.8h-80.1v-63.3h80.1V498.8z M728.3,372.6h-80.1v-63.3h80.1V372.6z" /><path d="M487.2,337.2H368.5v35.1h-72.7v-56.2h-26.7v56.2h-49v379.6h320.5V372.3h-53.4L487.2,337.2L487.2,337.2z M351.4,625.4h-80.1v-63.3h80.1V625.4z M351.4,498.8h-80.1v-63.3h80.1V498.8z M487.2,625.4h-80.1v-63.3h80.1V625.4z M487.2,498.8h-80.1v-63.3h80.1V498.8z" /></g>
                            </svg>
                        </div>
                        <h2 className="mb-1 text-black">Select Supplier</h2>
                        <div className='mb-1' style={{maxWidth:"500px", margin:"0 auto"}}>
                                <Select 
                                    theme={selectThemeColors}
                                    className='react-select text-left'
                                    classNamePrefix='select'
                                    defaultValue={colourOptions[0]}
                                    options={colourOptions}
                                    onChange={() => history.push('/BrandingPage')}
                                    isClearable={false}
                                />
                        </div>
                    
                        <Row className="col-md-12 mt-4 justify-content-center">
                          {/*  <div className="col-md-12"><h6>Recent Suppliers</h6></div>*/}
                            <div className="col-md-1 col-sm-12 d-flex flex-column" onClick={() => history.push('/BrandingPage')}>
                                <Media left  onChange={() => history.push('/BrandingPage')}>
                                    <Media object src={mediaImg1} height='64' width='64' alt='Generic placeholder image' />
                                    <h6 className='mb-0 mt-1'>Siyaram</h6>
                                    <small>5465</small>
                                </Media>
                            </div>
                            <div className="col-md-1 col-sm-12 d-flex flex-column" onClick={() => history.push('/BrandingPage')}>
                                <Media left onClick={() => history.push('/BrandingPage')}>
                                    <Media object src={mediaImg2} height='64' width='64' alt='Generic placeholder image' />
                                    <h6 className='mb-0 mt-1'>Raymond</h6>
                                    <small>858</small>
                                </Media>
                            </div>
                            <div className="col-md-1 col-sm-12 d-flex flex-column" onClick={() => history.push('/BrandingPage')} >
                                <Media left onClick={() => history.push('/BrandingPage')}>
                                    <Media object src={mediaImg3} height='64' width='64' alt='Generic placeholder image' />
                                    <h6 className='mb-0 mt-1'> Getzner</h6>
                                    <small>565283</small>

                                </Media>
                            </div>
                        </Row>
                        <div>
                        </div>
                </div>
            </div>
            </div>
        </div>
    )
}

export default SupplierList

