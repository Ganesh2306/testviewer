import { BrandTitle } from "./brandingComponent/BrandTitle"
import { ProductTypeCard } from "../BrandingPage/brandingComponent/ProductTypeCard"
import '../BrandingPage/brandingComponent/branding.css'
// ** Styles
import '@styles/base/pages/app-ecommerce.scss'

import background from "../../assets/images/pages/brand/branding.jpg"
import stock from '../../assets/images/pages/stock.jpg'
import sample from '../../assets/images/pages/sample1.jpg'
import nos from '../../assets/images/pages/nos1.jpg'
import customercollection from "../../assets/images/pages/seasons_fabric.jpg"
import seasonal_collezioni from '../../assets/images/pages/collezioni_app.jpg'


const arr = [
    { id: 1, name: "Stock", src: stock },
    { id: 2, name: "Nos", src: nos },
    { id: 3, name: "Samples", src: sample },   
    { id: 4, name: "My Collection", src: customercollection },
    { id: 5, name: "Seasonal Collection(Collezioni)", src: seasonal_collezioni }
]

const BrandingPage = (props) => {

    return ( 
        <div>     
            <div className="pinkbg">              
                <BrandTitle />              
                <div className="grandparent">
                <div className="parent">          
                        <div className="inner_div">                            {
                                arr.map((e, k) => {
                                    return <ProductTypeCard titleName={e.name} banner={e.src}/>
                                })
                            }
                        </div>
                </div>
                </div>
            </div>     
        </div>
    )
}

export default BrandingPage