import { useState, useContext, useEffect } from "react"
import { Link } from 'react-router-dom'
import {
    Row,
    Col,
    Input,
    Button,
    Card,
    CardBody,
    Label,
    // Dropdown,
    DropdownToggle,
    DropdownMenu,
    // Dropdown,
    InputGroup,
    InputGroupAddon, 
    DropdownItem,
    InputGroupText,  
    UncontrolledDropdown
} from "reactstrap"
//import {Dropdown} from 'primereact/dropdown'
//import "primereact/resources/primereact.min.css"
//import "primereact/resources/themes/lara-light-indigo/theme.css"
//import "primeicons/primeicons.css"

import { ChevronDown, List, Grid, Search, MoreVertical } from 'react-feather'
import { DeletePopUp, QrPopUp } from './popup/DeletePopUp'
import OpenExportExcel from './ExcelComponent/ExportExcel'
import AddDesign from "./popup/AddDesign"
import { AbilityContext } from '@src/utility/context/Can'
import axios from "axios"
import { skipState, setSkipFt, setStroge } from "./SkipCall"
import { selection } from "./Utility/selection"
import { PrintQr }  from './popup/PrintQr'
import { forColour } from './popup/ContentTable'
import Design from "../Design"
import { event } from "jquery"
const options = [
    { value: 'chocolate', label: 'Chocolate' },
    { value: 'strawberry', label: 'Strawberry' },
    { value: 'vanilla', label: 'Vanilla' }
  ]


let selectedObj = {}
let getFeatureListD = null
let getDesignTypeGroup = null
//let fs = true

export const getFTG = () => {
    return [getFeatureListD, getFilteredData({ rollData: getDesignTypeGroup })]
}
const Swal = require('sweetalert2')

const getFilteredData = (Data) => {
    try {
        const val = document.getElementById('collectionFabLibrary').value
        const options = val.split('-')
        let DesignTypes = null
        let designFeatures = []
        for (let i = 0; i < Data.rollData.allDesignTypesByRoles.length; i++) {
            if (`${Data.rollData.allDesignTypesByRoles[i].design_type_id}` === options[0].trim()) {
                DesignTypes = Data.rollData.allDesignTypesByRoles[i]
                for (let j = 0; j < DesignTypes.getDesignGroupsByRoleListDto.length; j++) {
                    if (`${DesignTypes.getDesignGroupsByRoleListDto[j].design_groups_id}` === options[1].trim()) {
                        designFeatures = DesignTypes.getDesignGroupsByRoleListDto[j].getDesignFeaturesByRoleListDto
                        return designFeatures
                    }
                }
            }
        }
        return designFeatures
    } catch (error) {
        return []
    }
}

let f = false
const Loop = (props) => {
    if (props.rollData !== null) {
        return (props.rollData.allDesignTypesByRoles.map((e, k) => {
            return (e.getDesignGroupsByRoleListDto.map((a, b) => {
                if (f) {
                    //pro.setOption(`${e.design_type_id} - ${a.design_groups_id}`)
                    f = false
                }
                return (<option
                    key={k + b + 25}
                    designtypeid={e.design_type_id}
                    designgroupid={a.design_groups_id}
                    value={`${e.design_type_id} - ${a.design_groups_id}`}
                    //temp={`${e.design_type_id} - ${a.design_groups_id}`} 
                    name={`${e.design_type_name}-${a.design_groups_name}`}
                    d_conf_i={`d_conf${e.design_Configuration_Id}`}
                >
                    {`${e.design_type_name}-${a.design_groups_name}`}
                </option>)
            }))
        }))
    } else {
        return <></>
    }
}

// ps-advance search txt-textsearch  isAllSearch- all search
export const searchHandel = async (ps, txt, isAllSearch, start, end) => {
    try {
        const isPtPg = document.getElementById('collectionFabLibrary').value
        if (isPtPg === undefined || isPtPg === "") {
            Swal.fire({
                icon: 'info',
                position: 'center',
                text: 'Please Assign Product Group',
                showConfirmButton: false,
                timer: 5000
            })
            return
        }
        // console.log(ps)
        let obj = {}
        let isText1 = true
        if (isAllSearch === true) {
            isText1 = false
        } else if (txt !== undefined || ps !== undefined) {
            isText1 = true
        }
    
        if (txt !== undefined) {
            obj = {
                folderId: "0",
                designName: txt,
                isText: isText1,
                isUserAdmin: false,
                createdBy: "string",
                filterSearchRequestDto: {
                    folderId: 0,
                    features: {},
                    isAnd: false
                },
                IsRating: false,
                IsName: false,
                start: start ? start : 0,
                end: end ? end : 15,
                Range: {},
                Iswearhouse: false,
                designstate: '',
                Difference: (start && end) ? end - start : 15,
                DesignTypeIdGroupId: document.getElementById('collectionFabLibrary').value
            }
        } else {
            const temp = {}
            if (isAllSearch === false) {
                Object.keys(selectedObj).map((e, k) => {
                    if (document.getElementById(e) !== null) {
                        const fname = document.getElementById(e)[0].text
                        if (fname !== selectedObj[e]) {
                            temp[document.getElementById(e)[0].text] = selectedObj[e].replace("dsp-", "")
                        }
                    }
                })
            }
            //const Range = {}
            obj = {
                folderId: "0",
                designName: "string",
                isText: isText1,
                isUserAdmin: false,
                createdBy: "string",
                filterSearchRequestDto: {
                    folderId: 0,
                    features: temp,
                    isAnd: true
                },
                IsRating: false,
                IsName: false,
                start: start ? start : 0,
                end: end ? end : 15,
                Range: {},
                Iswearhouse: false,
                designstate: '',
                Difference: (start && end) ? end - start : 15,
                DesignTypeIdGroupId: document.getElementById('collectionFabLibrary').value
            }
        }
    
    
            const response = await axios.post(`./Design/GetDesignSearchByfolderId`, obj)
          
        if (response.data === null) {
            Swal.fire({
                position: 'center',
                icon: 'info',
                title: 'Searching Data Not Found  !?',
                showConfirmButton: true
            })
            return
        }
        ps.setDesignList(JSON.parse(response.data))
        try {
            Object.keys(selectedObj).map((e, k) => {
                document.getElementById(e).value = selectedObj[e]  //a:{a:a, name:}
            })
        } catch (error) {

        }
    } catch (error) {

    }  
}

//!Top-Left
const LeftTop = (props) => {

const ability = useContext(AbilityContext)
    return (
        <>
        <Col className="col-xl-6 col-lg-6 col-md-12 col-sm-12 d-flex pr-0 ">
            { ability.can('add', 'Design') && <> <form className="form-inline flex-wrap select col-md-4 col-sm-12 pl-0 pr-50">
            <span className="float-left mr-1">Select Supplier</span>
            <select id="" 
            className="col-md-12 col-lg-12 col-md-6 col-sm-4 form-control float-left"
            ref={props.supplierref} 
           // onChange={}
            >       
                    {
                        props.splist && Object.keys(props.splist).map((e, k) => {
                           
                            return <option value={e}>{props.splist[e]}</option>
                            
                        })}
                </select> </form> </>}
        
            <form className="form-inline flex-wrap select col-md-4 col-sm-12 pr-50">
                <span className="float-left mr-1">Product Group</span>
                <select
                    id="collectionFabLibrary"
                    className="col-md-12 col-lg-12 col-md-12 col-sm-4 form-control float-left"
                    onChange={(e) => {

                        props.setSelect(e.target.value)
                        const isAllSearch = true
                        props.searchHandel(props.fprops, undefined, isAllSearch)
                    }}
                >
                    <Loop rollData={props.rollData} />
                </select>
                {/* <Dropdown options={options}/> */}
                {/*<div*/}
                {/*    className="col-lg-4 col-sm-4 custom-checkbox float-left" style={{ marginLeft: "6px", marginRight: "6px", float: "left" }} >*/}
                {/*    <Input*/}
                {/*        type="checkbox"*/}
                {/*        className="custom-control-input"*/}
                {/*        id="selectAll"*/}
                {/*    />*/}
                {/*    <Label className="custom-control-label" for="selectAll" style={{ marginLeft: "8px", marginRight: "6px", float: "left" }}*/}
                {/*    >Select All</Label>*/}
                {/*</div>*/}
                
            </form>
            <form className="form-inline flex-wrap select col-md-4 col-sm-12  pr-50">
                <span className="float-left mr-1">Warehouse</span>
                <select id="" className="col-md-12 col-lg-12 col-md-12 col-sm-4 form-control float-left">
                    <option>All</option>
                    <option>Stock</option>
                    <option>Noos</option>
                    <option>Sample</option>
                </select>
            </form>
            </Col>
        </>
     
    )
}

//!Top Right
const TopRight = (props) => {

    const [Del, setDel] = useState(false)
    const deltoggle = () => setDel(!Del)
    const [showqr, setshowqr] = useState(false)
    const toogleqr = () => setshowqr(!showqr)
    const [Ddata, setData] = useState(null)
    /* const [modal, setModal] = useState(false)
    const toggle = () => setModal(!modal) */
    const ability = useContext(AbilityContext)
    const [isOpen1, setOpen1] = useState(false)    
    const [printQrModel, setPrintQrModel] = useState(false)
    const toggleprint = () => { setPrintQrModel(!printQrModel) }

    return (
        <div className="col-xl-6 col-lg-6 col-md-10 col-sm-12 d-flex justify-content-end" >    
           <div className="button-menu">
                <div className="text-lg-right d-lg-flex slidemenu d-inline-flex" style={{ justifyContent: "right" }}>
                       
                        <AddDesign myColour={props.myColour} modal={props.modal} toggle={props.toggle} />               
                        {ability.can('display', 'Design') && 
                        <Button.Ripple color='success'
                            type="button"
                            id="add_designBTN"
                            className="btn btn-sm btn-success"
                        onClick={async () => {
                                const isStorageF = await axios.post(`./Design/GetStorageLocation`)
                                if (!isStorageF.data.isStorage) {
                                    Swal.fire({
                                        position: 'center',
                                        icon: 'info',
                                        title: 'Please configure storage  !?',
                                        showConfirmButton: true
                                    })
                                } else {
                                    props.toggle()
                                }
                            }
                            }
                        >
                       <i className="fas fa-plus-circle mr-1"></i> Add Designs
                        </Button.Ripple>}
                        
                        {ability.can('display', 'Design') && 
                        <Button.Ripple color='success'
                            type="button"
                            id="openQ3DQR"
                            className="btn btn-sm btn-success " style={{ marginLeft: "4px" }}
                            onClick={() => {
                                //ToDo :show Some modal
                                // {showqr, toogleqr, src }
                                toogleqr()
                            }}
                        >
                        <i className="fas fa-qrcode mr-1"></i> Q3D
                        </Button.Ripple >}

                    <QrPopUp showqr={showqr} toogleqr={toogleqr} src={selection.getQrLink(true)} />

                    {/* delete button added below */}
                    {/*  <button
                        type="button"
                        onClick={deltoggle}
                        id="delete_design_btn"
                        className="btn btn-sm btn-secondary waves-effect waves-light mb-2"
                        title="Delete"
                        data-original-title="Delete Design" style={{ marginLeft: "4px" }}
                    >
                        <i className="fas fa-trash-alt" >
                            <DeletePopUp modal={Del} setDel={setDel} toggle={deltoggle} />
                        </i>                      
                    </button>*/}
                    
                   {/* below  buttons added in dropdown manisha */}      
                    {/*<Button
                        type="button"
                        id="printBtn"
                        className="btn btn-sm btn-secondary waves-effect waves-light mb-2" style={{ marginLeft: "4px" }}
                        title="Print"
                    >
                        <i
                            className="fas fa-print"
                        ></i>
                        <span className="caret"></span>
                    </Button>
                    <div className="dropdown-menu" >
                        <a
                            className="dropdown-item"
                            href="#"
                            data-toggle="modal"
                            data-target="#qr_print"
                        >
                            Print QR</a
                        >
                        <a
                            className="dropdown-item"
                            href="#"
                        >
                            Print Design</a
                        >
                    </div>

                   
                    <label className="custom-file-upload btn btn-sm btn-secondary mb-2" style={{ marginLeft: "4px" }} title="Import Excel">
                        <i
                            className="fas fa-file-import"
                            data-toggle="tooltip"
                            data-placement="bottom"
                            data-original-title="Import Excel"
                        ></i>
                        <input
                            id="importExcel"
                            type="file"
                            accept=".xls,.xlsx"
                            multiple=""
                            style={{ display: 'none' }}
                            onChange={async (e) => {
                                const tpgpID = document.getElementById('collectionFabLibrary').value
                                const obj = {}
                                obj['FolderId'] = 0
                                obj['designTypeId'] = tpgpID.split('-')[0].trim()
                                obj['designGroupId'] = tpgpID.split('-')[1].trim()
                                obj['OrganisationId'] = 0
                                const file = e.target.files[0]

                                const formPayload = new FormData()
                                formPayload.append('file', file)
                                formPayload.append('alldata', JSON.stringify(obj))
                            

                                await axios({
                                    url: './Design/SaveDesignMasterExcel',
                                    method: 'post',
                                    data: formPayload,
                                    headers: { 'Content-Type': 'multipart/form-data' },
                                    enctype: 'multipart/form-data'

                                }).then(e => {

                                    if (e.data !== null && e.data !== undefined) {
                                        if (JSON.parse(e.data.issaved)) {
                                            Swal.fire(
                                                'Success',
                                                'Data saved successfully !!',
                                                'success'
                                            )

                                            setTimeout(async () => {
                                                props.setreRender(!props.reRender)
                                            }, 200)
                                        } else {
                                            Swal.fire({
                                                icon: 'info',
                                                title: 'Oops...',
                                                text: 'Data not saved!'
                                            })
                                        }
                                    } else {
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Oops...',
                                            text: 'Something went wrong!'
                                        })
                                    }

                                })

                                e.target.value = ''

                            }}
                        />
                    </label>
                    <button
                        id="exportExcelBtn"
                        type="button"
                        className="btn btn-sm btn-secondary waves-effect waves-light mb-2" style={{ marginLeft: "4px" }}
                        data-toggle="modal"
                        data-target="#export_model"
                        title="Export Excel"
                        onClick={() => {
                            setOpen1(!isOpen1)
                        }}
                    >
                        <i
                            className="fas fa-file-export"
                            data-toggle="tooltip"
                            data-placement="bottom"
                            title=""
                            data-original-title="Export Excel"
                        >

                        </i>
                    </button>*/}
                 
                    {/* above buttons added in dropdown manisha */}
                    <OpenExportExcel rollData={props.rollData} setOpen1={setOpen1} isOpen1={isOpen1} />
                  
                    <UncontrolledDropdown>
                    {ability.can('display', 'Design') && <DropdownToggle className='hide-arrow ml-50 bg-secondary d-block text-center' tag='a' style={{width:'32px', height:'28px'}}>
                    <MoreVertical className='text-white mt-50' size={20} style={{width:'18px', height:'18px'}}/>
                    </DropdownToggle>}
                    <DropdownMenu right>                        
                        <div className='w-100 '>                               
                                <label className="custom-file-upload w-100 customdropitem" title="Import Excel">
                                        <i
                                            className="fas fa-file-import mr-50"
                                            data-toggle="tooltip"
                                            data-placement="bottom"
                                            data-original-title="Import Excel"
                                        ></i>
                                        <input
                                            id="importExcel"
                                            type="file"
                                            accept=".xls,.xlsx"
                                            multiple=""
                                            style={{ display: 'none' }}
                                        onChange={async (e) => {
                                    
                                                const tpgpID = document.getElementById('collectionFabLibrary').value
                                                const obj = {}
                                                obj['FolderId'] = 0
                                                obj['designTypeId'] = tpgpID.split('-')[0].trim()
                                                obj['designGroupId'] = tpgpID.split('-')[1].trim()
                                                obj['OrganisationId'] = 0
                                                const file = e.target.files[0]

                                                const formPayload = new FormData()
                                                formPayload.append('file', file)
                                                formPayload.append('alldata', JSON.stringify(obj))


                                                await axios({
                                                    url: './Design/SaveDesignMasterExcel',
                                                    method: 'post',
                                                    data: formPayload,
                                                    headers: { 'Content-Type': 'multipart/form-data' },
                                                    enctype: 'multipart/form-data'

                                                }).then(e => {

                                                    if (e.data !== null && e.data !== undefined) {
                                                        if (JSON.parse(e.data.issaved)) {
                                                            Swal.fire(
                                                                'Success',
                                                                'Data saved successfully !!',
                                                                'success'
                                                            )

                                                            setTimeout(async () => {
                                                                props.setreRender(!props.reRender)
                                                            }, 200)
                                                        } else {
                                                            Swal.fire({
                                                                icon: 'info',
                                                                title: 'Oops...',
                                                                text: 'Data not saved!'
                                                            })
                                                        }
                                                    } else {
                                                        Swal.fire({
                                                            icon: 'error',
                                                            title: 'Oops...',
                                                            text: 'Something went wrong!'
                                                        })
                                                    }

                                                })

                                                e.target.value = ''

                                            }}
                                    />
                                    Import Excel
                                </label>
                            
                            
                        </div>
                        <DropdownItem className='w-100'>
                                    <button
                                    id="exportExcelBtn"
                                    type="button"
                                    className="btn btn-sm waves-effect waves-light btn-white p-0" 
                                    data-toggle="modal"
                                    data-target="#export_model"
                                    title="Export Excel"
                                    onClick={() => {
                                        setOpen1(!isOpen1)
                                    }}
                                >
                                    <i
                                        className="fas fa-file-export mr-50 "
                                        data-toggle="tooltip"
                                        data-placement="bottom"
                                        title=""
                                        data-original-title="Export Excel"
                                    >

                                    </i>
                                    Export Excel
                                </button>
                        </DropdownItem>
                        <DropdownItem className='w-100'>
                                <button
                                type="button"
                                id="printBtn"
                                className="btn btn-sm btn-white waves-effect waves-light btn-white p-0"
                                title="Print"
                                onClick={() => toggleprint()}
                            >
                                <i
                                    className="mr-50 fas fa-print"
                                ></i> Print
                                <span className="caret"></span>                               
                            </button>
                            <PrintQr printQrModel={printQrModel} toggleprint={toggleprint} unit = "false" designId = {selection.slected.id}/>
                        </DropdownItem>
                        
                    </DropdownMenu>
                    </UncontrolledDropdown>
                    
                </div>
                
            </div> 
           
        </div>

        
    )
}

//!Dynamic with Div <SelectBoxWithDiv />
const SelectBoxWithDiv = (props) => {
    //FidName
    const [options, setoptions] = useState(``)
    const Options = (op) => {
        return (
            <option tempid={op.value.design_featuretype_id} value={op.value.design_featuretype_name}>{op.value.design_featuretype_name}</option>
        )
    }
    /* useEffect(() => {
        
        Object.keys(selectedObj).map((e, k) => {
            document.getElementById(e).value = selectedObj[e]
        })
    }, [props.ftdata]) */
    const handelSelectChange = (e) => {
        if (e.target.id !== e.target.value) {
            selectedObj[e.target.id] = e.target.value
        } else {
            delete selectedObj[e.target.id]
        }
    }

    return (
        <>
            <Col className="col-md-4 col-lg-2 flip mb-8 mb-1"
                style={{ paddingLeft: "0px", paddingRight: "4px", float: "left" }}>
                <select
                    id={`dsp-${props.FidName[0].id}`}
                    type="text"
                    className="_featureTypeSearch form-control"
                    selectcss="0"
                    sfid={props.FidName[0].id}
                    sfname={props.FidName[0].name}
                    onChange={handelSelectChange}
                >
                    <option value={`dsp-${props.FidName[0].id}`}>{props.FidName[0].name}</option>
                    {
                        props.ftdata.map((e, k) => {
                            return <Options key={k} value={e} />
                        })
                    }
                </select>
            </Col>
        </>
    )
}
//! id: collectionFabLibrary

let ftData1 = []
const SearchToggleComponent = (props) => {
    const [ft, setft] = useState(ftData1)
    useEffect(() => {
        ftData1 = getFilteredData(props)
        selectedObj = {}
        return () => {
            props.setSelect(null)
        }
    }, [props.select])

    ftData1 = getFilteredData(props)
    return (
        <>
            <div >
                <div id="cardCollpase1"  >
                    <div className="AdvanceSearch">
                        {
                            ftData1.map((e, k) => {
                                let ftdata = []
                                const FidName = []
                                //props.featureTData = []
                                if (props.featureTData !== null) {
                                    for (let i = 0; i < props.featureTData.length; i++) {
                                        if (props.featureTData[i].design_feature_id === e.design_features_id) {
                                            ftdata = props.featureTData[i].featureTypeList
                                        }
                                    }
                                }
                                FidName.push({ id: e.design_features_id, name: e.design_features_name })
                                return <SelectBoxWithDiv key={`${k}-select-m`} FidName={FidName} 
                                ftdata={ftdata} tid={k} 
                                setSelect={props.setSelect} />
                            })
                        }

                        <div className="col-md-4 col-lg-2 d-flex pl-0" >
                            <button
                                type="button"
                                id="AdvanceSearchBtn"
                                className="btn btn-xs btn-primary waves-effect waves-light mb-2 px-1 py-50"
                                onClick={() => {
                                    const isAllSearch = false
                                    searchHandel(props, undefined, isAllSearch)
                                }
                                }
                            >
                                Search
                               {/* <i class="fa fa-search" aria-hidden="true"></i>*/}
                               </button>
                            <button
                                type="button"
                                id="ResetBtn"
                                className="btn btn-xs btn-primary waves-effect waves-light mb-2" style={{ marginLeft: "4px" }}
                                onClick={() => {
                                    props.setSelect(!props.select)
                                    const isAllSearch = true
                                    searchHandel(props, undefined, isAllSearch)
                                }
                                }
                            >
                                Reset
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

//!TopBar

const InputSearchCombo = (props) => {
        return (
            <>
                <Row
                    style={{ display: 'block'}}>
                    <InputGroup className='col-lg-4 col-md-6 col-sm-12 d-block' >
                        <div className="input-icons" style={{ position: 'relative' }}>
                            <Input id='txtSearch' className='rounded-left w-100' style={{ borderRadius: '0' }}
                                //defaultValue={searchValue}
                                type='text' onChange={(e) => {
                                    //setSearchValue(e.target.value)
                                }}
                            >

                            </Input>
                            <i className="fa fa-times"  aria-hidden="true" role='button' onClick={() => {
                                document.getElementById('txtSearch').value = ''
                            }} style={{ position: 'absolute', right: '60px', top: '0.875rem' }}></i>
                        </div>
                        <InputGroupAddon addonType="append">
                            <Button className="bg-light text-white px-1" role="button" onClick={(e) => {
                                const isAllSearch = false
                                searchHandel(props, document.getElementById('txtSearch').value, isAllSearch)
                            }} ><i class="fa fa-search" size='18px' aria-hidden="true"></i></Button>
                        </InputGroupAddon>
                    </InputGroup>
                </Row>
            </>
        )
    }

const TopBar = (props) => {

    const [advsearch, setadvsearch] = useState(false)
    const [searchValue, setSearchValue] = useState('')
    const resetInput = event => {
        setSearchValue('')
    }
    const [select, setSelect] = useState(null)
    //!LeftTopDown

    const [rollData, setrollData] = useState(null)
    const [featureTData, setfeatureTData] = useState(null)
    const [modal, setModal] = useState(false)
    const toggle = () => setModal(!modal)
    const [Del, setDel] = useState(false)
    const deltoggle = () => setDel(!Del)

    useEffect(async () => {
        //props.setDesignList(null)
        console.log({
        supplierref : props.supplierref.current ? parseInt(props.supplierref.current.value) : 0
        })

        forColour.value = ""
        if (skipState.skipFt) {
           
            /*  if (skipState.storageCheck) {
                 const isStorageF = await axios.post(`./Design/GetStorageLocation`)
                 setStroge(false)
             } */
             //const constArr = ['warehouse', 'product', 'rating', 'price', 'credit', 'date', 'stock']  Abhishek
             /* if (!getDesignTypeGroup) { */
              const response = await axios.get(`./Design/GetRoleDesignConfigurationByRole?RoleId=${0}`)
              getDesignTypeGroup = response.data
              
             /* } */
           //Abhishek
            /* response.data.allDesignTypesByRoles.forEach((e, k) => {
                e["getDesignGroupsByRoleListDto"].forEach((a, c) => {
                    a["getDesignFeaturesByRoleListDto"].forEach((b, cc) => {
                   if (constArr.includes(response.data.allDesignTypesByRoles[k].getDesignGroupsByRoleListDto[c].getDesignFeaturesByRoleListDto[cc].design_features_name.toLowerCase())) {
                       delete response.data.allDesignTypesByRoles[k].getDesignGroupsByRoleListDto[c].getDesignFeaturesByRoleListDto[cc]
                   }
                    })
                    response.data.allDesignTypesByRoles[k].getDesignGroupsByRoleListDto[c] = a["getDesignFeaturesByRoleListDto"].filter((e) => {
                        return e !== null
                    })
                })
            }) */
           
            //ToDo: -> not in('Warehouse','Product','Rating','Price','Credit','Date','Stock')
            /* if (!getFeatureListD) { */
                const resGetFt = await axios.get(`./Design/GetFeatureTypeList`)
                getFeatureListD = resGetFt.data
                setfeatureTData(resGetFt.data)
                setrollData(response.data)
            /* } */
            const isAllSearch = true
            await searchHandel(props, undefined, isAllSearch)
        } else {
            setSkipFt(true)
            const isAllSearch = true
            setTimeout(async () => {
                await searchHandel(props, undefined, isAllSearch)
            }, 1000)
        }
        // console.log(props.reRender)
        return () => {
            forColour.value = ""
            //props.setDesignList(null)
        }
    }, [modal, props.reRender])

    return (
        <>
            <Card className="contain1">              
                <CardBody>
                    <Row className="mb-1">
                        { /** Top Left Side */}
                        <LeftTop rollData={rollData} setSelect={setSelect} searchHandel={searchHandel} fprops={props} splist={props.splist} supplierref={props.supplierref}/>
                        <TopRight myColour={props.myColour} rollData={rollData} modal={modal} setModal={setModal} toggle={toggle} setreRender={props.setreRender} reRender={props.reRender}  />
                     
                        {/*<div className="text-lg-right thumb_grid_select">*/}
                        {/*    <div className="d-flex">*/}
                        {/*    <div*/}
                        {/*        className="custom-checkbox float-left " style={{ marginLeft: "6px", marginRight: "6px", float: "left" }} >*/}
                        {/*        <Input*/}
                        {/*            type="checkbox"*/}
                        {/*            className="custom-control-input  mt-25"*/}
                        {/*            id="selectAll"*/}
                        {/*        />*/}
                        {/*        <Label className="custom-control-label" for="selectAll" style={{ marginLeft: "20px", marginRight: "6px", float: "left" }}*/}
                        {/*        >Select All</Label>*/}
                        {/*    </div>*/}
                        {/*    <button*/}
                        {/*        type="button"*/}
                        {/*        onClick={deltoggle}*/}
                        {/*        id="delete_design_btn"*/}
                        {/*        className="btn btn-sm waves-effect waves-light"*/}
                        {/*        title="Delete"*/}
                        {/*            data-original-title="Delete Design" style={{ marginLeft: "4px", padding: "4px", paddingTop: "0", marginTop: "-4px" }}*/}
                        {/*    >*/}
                        {/*        <i className="fas fa-trash-alt" style={{fontSize: "0.9rem"}} >*/}
                        {/*            <DeletePopUp modal={Del} setDel={setDel} toggle={deltoggle} />*/}
                        {/*        </i>                             */}
                        {/*    </button>*/}
                        {/*    </div>    */}

                          
                        {/*    <div style={{ float: "right" }}>*/}
                        {/*        <div style={{ float: "right", padding: "4px", paddingTop: "2px", paddingRight: "4px" }}> |    Total  {(props.designList.totalCount !== null || props.designList.totalCount !== undefined) ? props.designList.totalCount : ''} </div>*/}
                        {/*        <List onClick={() => {*/}
                        {/*            props.setImgViewToggle(false)*/}
                        {/*        }} color={props.ImgViewToggle ? '#423F3E' : `#CF0000`} size={28} style={{ float: "right", padding: "6px", cursor: "pointer", paddingTop: "0" }} />*/}
                        {/*        <Grid color={props.ImgViewToggle ? '#CF0000' : `#423F3E`} size={28} onClick={() => {*/}
                        {/*            props.setImgViewToggle(true)*/}
                        {/*        }} style={{ float: "right", padding: "6px", cursor: "pointer", paddingTop: "0" }} />*/}
                        {/*        &nbsp; &nbsp; &nbsp;*/}
                        {/*    </div>*/}
                        {/*</div>*/}
                    </Row>
                    <Row>
                        <div className="col-xl-12 col-md-12 m-0 d-lg-flex flex-lg-column flex-sm-row">
                            <div className="col-lg-12 col-md-12 col-sm-12 p-0">
                             <div className="filterPanel">
                                <div className="card-widgets pt-0">
                                    <a
                                        id="filter-expand"
                                        role="button"
                                        aria-expanded="false"
                                        aria-controls="cardCollpase1"
                                        className="btn btn-secondary btn-xs waves-effect waves-light m-0 collapsed"
                                        style={{ lineHeight: '1rem' }}
                                        onClick={() => {
                                            setadvsearch(!advsearch)
                                        }}
                                    >
                                        {advsearch ? <i className="fas fa-minus mr-50"></i> : <i className="fas fa-plus mr-50"></i>}
                                        Filter
                                    </a>
                                </div>
                                {/** search component */}
                                {advsearch ? <SearchToggleComponent setDesignList={props.setDesignList} advsearch={advsearch} setSelect={setSelect} select={select} rollData={rollData} featureTData={featureTData} /> : <InputSearchCombo setDesignList={props.setDesignList} />}
                                {/** Add That Div */}
                                    </div>
                             </div>

                            <div className="text-lg-right thumb_grid_select">
                                <div className="d-flex totalcount" style={{ float: "left", paddingLeft: "14px", paddingRight: "14px", paddingTop: "5px" }}> Total  {(props?.designList?.totalCount !== null || props?.designList?.totalCount !== undefined) ? props?.designList?.totalCount : ''} </div>
                                <div className="d-flex">
                                    <div
                                        className="custom-checkbox float-left " style={{ marginLeft: "6px", marginRight: "6px", float: "left" }} >
                                        <Input
                                            type="checkbox"
                                            className="custom-control-input  mt-25"
                                            id="selectAll"
                                        />
                                        <Label className="custom-control-label" for="selectAll" style={{ marginRight: "6px", float: "left" }}
                                        >Select All</Label>
                                        <button
                                            type="button"
                                            onClick={deltoggle}
                                            id="delete_design_btn"
                                            className="btn btn-sm btn-light"
                                            title="Delete"
                                            data-original-title="Delete Design" style={{ marginLeft: "4px", padding: "4px", paddingTop: "0" }}
                                        >
                                            <i className="fas fa-trash-alt" style={{ fontSize: "0.9rem" }} >
                                                <DeletePopUp modal={Del} setDel={setDel} toggle={deltoggle} />
                                            </i>
                                        </button>
                                    </div>
                                    <div className='mb-1'>
                                        <List onClick={() => {
                                            props.setImgViewToggle(false)
                                        }} color={props.ImgViewToggle ? '#423F3E' : `#0a66c2`} size={30} style={{ float: "right", padding: "6px", cursor: "pointer", paddingTop: "0" }} />
                                        <Grid color={props.ImgViewToggle ? '#0a66c2' : `#423F3E`} size={30} onClick={() => {
                                            props.setImgViewToggle(true)
                                        }} style={{ float: "right", padding: "6px", cursor: "pointer", paddingTop: "0" }} />
                                        &nbsp; &nbsp; &nbsp;
                                    </div>
                                </div>
                            </div>
                        </div>
                    </Row>
                </CardBody>
            </Card>
        </>
    )
}

export default TopBar
