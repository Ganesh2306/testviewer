
import classnames from 'classnames'
import InputPasswordToggle from '@components/input-password-toggle'
import { Link, useHistory } from 'react-router-dom'


import { Row, Col, CardTitle, CardText, Form, FormGroup, Label, Input, CustomInput, Button } from 'reactstrap'
import '@styles/base/pages/page-auth.scss'
const LoginView = (props) => {
  const history = useHistory()
    return (
        <div className='auth-bg auth-viewer text-center'>          
            <img class="login-logo-viewer text-lg-center mb-1 hidden-xs hidden-sm" src="../../design_archive_logo.png" alt="Logo"/>
            <CardTitle tag='h3' className='font-weight-bold mb-1 text-lg-left login-header'>
              Welcome to Design Archive!
            </CardTitle>         
           <Form className='auth-login-form mt-2' onSubmit={props.handleSubmit(props.onSubmit)}>
              <FormGroup className='text-lg-left'>
                <Label className='form-label login-norm-text' for='login-email'>
                  Username
                </Label>
                <Input
                  autoFocus
                  type='text'
                  value={props.email}
                  id='login-email'
                  name='login-email'
                  placeholder='username'
                  onChange={e => props.setEmail(e.target.value)}
                  className={classnames({ 'is-invalid': props.errors['login-email'] })}
                  innerRef={props.register({ required: true, validate: value => value !== '' })}
                />
              </FormGroup>
              <FormGroup>
                <div className='d-flex justify-content-between'>
                  <Label className='form-label login-norm-text' for='login-password'>
                    Password
                  </Label>                
                    <small className='login-forgotpass' onClick={() => props.setforget(false)}>Forgot Password?</small>                
                </div>
                <InputPasswordToggle
                  value={props.password}
                  id='login-password'
                  name='login-password'
                  className='input-group-merge'
                  onChange={e => props.setPassword(e.target.value)}
                  className={classnames({ 'is-invalid': props.errors['login-password'] })}
                  innerRef={props.register({ required: true, validate: value => value !== '' })}
                />
              </FormGroup>
              <FormGroup className='text-lg-left'>
                <CustomInput type='checkbox' className='custom-control-Primary' id='remember-me' label='Remember Me' />
              </FormGroup>
              <Button.Ripple type='submit' color='primary' block className='rounded-0'>
                Sign in
              </Button.Ripple>
            </Form>
            <p className='text-center mt-2' style={{fontSize:'12px'}}>
              <span className='mr-25'>New To Design Archive ?</span>
              <Link to='plan'>
                <span >Register Now!</span>
              </Link>              
            </p>
        </div>
    )
  }

  export default LoginView