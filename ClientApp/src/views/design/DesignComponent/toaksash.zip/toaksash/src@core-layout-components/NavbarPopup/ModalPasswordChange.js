﻿import React, { useState } from 'react'
import "react-datepicker/dist/react-datepicker.css"
import DatePicker from "react-datepicker"

import { FormGroup, Input, Label, Col, Modal, Button, ModalHeader, ModalBody, ModalFooter, Row, DropdownItem, Form } from 'reactstrap'
import InputPasswordToggle from '@components/input-password-toggle'


export const ModelPasswordChange = (props) => {
/*    const [successPassword, setsuccessPassword] = useState(false)*/
    return (
        <div>
            <Modal isOpen={props.cpmOpen} toggle={() => props.setCpm(false)} className='modal-sm modal-dialog-centered' backdrop='static' >
                <ModalHeader toggle={() => props.setCpm(false)}> Change Password</ModalHeader>

                <ModalBody style={{ minHeight: '250px' }}>
                    <Form>
                        <Row> 
                            <Col sm='12'>
                                <FormGroup>
                                    <InputPasswordToggle
                                        label='Old Password'
                                        htmlFor='old-password'
                                        name='old-password'                                      
                                    />
                                </FormGroup>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm='12'>
                                <FormGroup>
                                    <InputPasswordToggle
                                        label='New Password'
                                        htmlFor='new-password'
                                        name='new-password'
                                    />
                                </FormGroup>
                            </Col>
                            <Col sm='12'>
                                <FormGroup>
                                    <InputPasswordToggle
                                        label='Retype New Password'
                                        htmlFor='retype-new-password'
                                        name='retype-new-password'                                      
                                    />
                                </FormGroup>
                            </Col>                           
                        </Row>
                    </Form>
                </ModalBody>
                <ModalFooter>
                    <Button color='primary' onClick={() => {
                        if (props.cpmOpen === false) {
                            props.setCpm(true)
                        }  else {
                            props.setCpm(false)
                            props.setsuccessPassword(true)
                        }
                    }}>
                        Save
                    </Button>
                </ModalFooter>
            </Modal>
        </div>
    )
}
/*props.setCpm(false)*/