import { useState, useEffect, useContext } from "react"
import { 
  Button,
  CardBody,  
  CardImg, Input, Label, Form, Modal, ButtonGroup, Table, Row} from "reactstrap"
  import { ChevronDown, Edit, Hexagon, Star, Grid, List } from 'react-feather'
import ReactPaginate from 'react-paginate'
import DataTable from 'react-data-table-component'
import { DeletePopUp } from "./popup/DeletePopUp"
import { imgData, ImgColumn} from './data'
import ThreeD_Design from "./popup/ThreeD_Design"
import { AbilityContext } from '@src/utility/context/Can'
import '../design.css'
import axios from "axios"
import TopBarOrg, {InputSearchCombo} from "./TopBarOrg"
import { object } from "prop-types"
import { faUserEdit } from "@fortawesome/free-solid-svg-icons"
import classnames from 'classnames'

let saveConfgi = {}
export const SaveConfigToArr = () => Object.values(saveConfgi)

let chek = false
export const SetAll = function (p) { chek = p }


const CreateObject = (id, info) => {
   
    if (info.td_showroom_configuration_id !== undefined) {
        //!ShowRoom
        const TdShowroomConfiguration = new Object()
        TdShowroomConfiguration.state = info.td_showroom_configuration_id !== 0 ? 3 : 0 
        TdShowroomConfiguration.td_Showroom_Configuration_Id = info.td_showroom_configuration_id
        TdShowroomConfiguration.td_Three_DImage_Id = info.tdImages[0].td_threed_image_id
        TdShowroomConfiguration.td_Organisation_Id = 0
        TdShowroomConfiguration.td_Order_No = 0
            return TdShowroomConfiguration
    } else {
        const TdQvImageConfiguration = new Object()
                            TdQvImageConfiguration.state = info.td_Qv_Image_Configurations_Id !== 0 ? 3 : 0 
                            TdQvImageConfiguration.td_Qv_Image_Configurations_Id = info.td_Qv_Image_Configurations_Id
                            TdQvImageConfiguration.td_Threed_Image_Id = info.tdImages[0].td_threed_image_id
                            TdQvImageConfiguration.td_Organisation_Id = 0
                            TdQvImageConfiguration.td_Order_No = 0
            return TdQvImageConfiguration
    }
}

const operation = (type, id, obj, ref) => {
    if (type === 'add') {
        saveConfgi[id] = CreateObject(id, obj)
    } else if (type === 'remove') {
       ref === 0  ? delete saveConfgi[id] : saveConfgi[id] = CreateObject(id, obj)
    }
}

export const rmAllSaveConfig = () => {
    saveConfgi = {}
}

window.sv = () => saveConfgi

const CustomPagination = ({ pagestartref, pagendref, count, rerender, prerender, newselctionref}) => {
   
    const [perPage, setparPage] = useState(pagendref.current - pagestartref.current)  
    const pcount =  Math.ceil(count / perPage)
    const [selectedPage, setSelectedPage] = useState(0) // 1 
    const handlePagination = page => {
       
        setSelectedPage(page.selected)
        pagestartref.current = page.selected === 0 ? 1 : page.selected * perPage
        pagendref.current = 25
        rerender(e => !e)
    }

    useEffect(() => {
      if (pagestartref.current === 0) {
        setSelectedPage(0)
      }
      return () => {
        
      }
    }, [prerender])
    return (
        <ReactPaginate
                previousLabel={''}
                nextLabel={''}
                breakLabel='...'
                pageCount={pcount || 1}
                onPageChange={page => handlePagination(page)}
                marginPagesDisplayed={25}
                pageRangeDisplayed={2}
                activeClassName='active'
                forcePage={selectedPage}  //from !== undefined ? Math.ceil(from / size) : 0            
                pageClassName={'page-item'}
                nextLinkClassName={'page-link'}
                nextClassName={'page-item next'}
                previousClassName={'page-item prev'}
                previousLinkClassName={'page-link'}
                pageLinkClassName={'page-link'}
                breakClassName='page-item'
                breakLinkClassName='page-link'
                containerClassName={
                    'pagination react-paginate separated-pagination pagination-sm justify-content-end pr-1 mt-1'
        }
      />
    )
}

    //! Image Table View
// const Table = () => {
//     return (
//             <DataTable
//               noHeader
//               nopagination
//               paginationServer
//               className='react-dataTable'
//               columns={ ImgColumn }          
//               sortIcon={<ChevronDown size={10} />}           
//               data={imgData}
//             />
//         )
//     }

const OnHoverOption = ({ ability, modal, toggle, id, info, uid, select, forceRerender, credits,
     newselctionref, creditlimit, credit }) => {
      const [editmodal, seteditModal] = useState(false)
      const edittoggle = () => seteditModal(!editmodal)
        //console.log(pr.src)
        const [Del, setDel] = useState(false)
        const deltoggle = () => setDel(!Del)
        const [check, setCheck] = useState(false)

         const obj = [
                         {
                          state : 3,
                          td_threed_image_id : info.tdImages[0].td_threed_image_id ? info.tdImages[0].td_threed_image_id : 0
                          }
                     ]

        useEffect(() => {
          setCheck((info.td_Qv_Image_Configurations_Id !== undefined && info.td_Qv_Image_Configurations_Id !== 0) || (info.td_showroom_configuration_id !== undefined && info.td_showroom_configuration_id !== 0))
          
          return () => {
            setCheck(false)
          }
        }, [id, (info.td_Qv_Image_Configurations_Id !== undefined && info.td_Qv_Image_Configurations_Id !== 0) || (info.td_showroom_configuration_id !== undefined && info.td_showroom_configuration_id !== 0)])
        
        const rConfigid = (a, b) => {
            if (a !== undefined) {
                return a
            } else {
                return b
            }
             
        }

    return (
            <>
            <Form>              
            <div className="custom-checkbox" >
            <Label 
            //className="custom-control-label" 
            >
            <Input
                type="checkbox"
                //className="custom-control-label"
                //className="custom-control-input"
                            id="" //defaultChecked={select }
                            checked={check}
                onChange={
                    (e) => {
                        console.log(info)
                        //setusercheckEdit(!usercheckEdit)
                        console.log({credits})
                        const crd = parseInt(newselctionref.current?.getAttribute('count'))
                        if (check) {
                            newselctionref.current?.setAttribute('count', crd - parseInt(credits))
                            newselctionref.current.textContent = `[selection ${crd - parseInt(credits)}]`
                            
                            operation('remove', info.tdImages[0].td_threed_image_id, 
                            info, 
                            rConfigid(info.td_Qv_Image_Configurations_Id, info.td_showroom_configuration_id)) //! remove this -> from saveConfig Obj
                        } else {
                            if (crd + credit >= creditlimit) { 
                                return alert('Hey You Have exceeds creditLimit')
                            }
                            newselctionref.current?.setAttribute('count', crd + parseInt(credits))
                            newselctionref.current.textContent = `[selection ${crd + parseInt(credits)}]`
                            operation('add', info.tdImages[0].td_threed_image_id, 
                            info, 
                            rConfigid(info.td_Qv_Image_Configurations_Id, info.td_showroom_configuration_id)) //! Add this -> to saveConfig Obj 
                        }
                        setCheck(!check)
                    }
                }
                />
                </Label>
           </div>            
            </Form>   
                {ability.can('add', '3DImages') && <div className="iconstop" style={{ float: 'left', zIndex: '9' }}>

                    <ThreeD_Design modal={editmodal} toggle={edittoggle} uid={id} headername = "Modify 3D Images" subheadername = "Edit & Modify 3D Images" />
                    <div>
                    {ability.can('Display', '3DImages') && <Button className="iconthumb" color='light' title="Edit" >
                        <Edit role='button' onClick={() => {
                            edittoggle()
                            forceRerender()
                        }}
                        />
                    </Button>}
                    </div>

                {ability.can('Display', '3DImages') && <Button className="iconthumb" onClick={(e) => {
                     deltoggle()
            }} color='light' title="Remove">
                    <i className="fa fa-times " aria-hidden="true" role='button'  ></i>
                    <DeletePopUp modal={Del} toggle={deltoggle} delobj = {obj} forceRerender={forceRerender} />
                </Button> }
                </div>}
           
            </>
        )
    }

//!Img Box For Loop   
const ImgBox = ({ id, src, name, ability, toggle, modal, e, k, select, credits, Exclusive,
     forceRerender,  newselctionref, creditlimit, credit }) => {
        const [onHover, setonHover] = useState(false)
        const [editmodal, seteditModal] = useState(false)
        const edittoggle = () => seteditModal(!editmodal)
    return (
        <tr className = 'ecommerce-card card mb-2 rounded-0'>
         <td>1</td>
         <td className="thumb-bg">  
                        <div className='item-img text-center mx-auto position-relative p-0' id="gallery_3d"  > 
                            <div className="top">
                            <CardImg top src={src} />
                            {Exclusive && <div className="excl">Exclusive </div>}
                            </div>
                      
                    </div>
         </td>
         <td className="thumb-cardbody">
                        <CardBody> 
                                <div  className= "img_title" >{name}</div>
                        </CardBody>  
         </td> 
         <td className="credit_box">
                <div className="credit_score"> 
                                    <div>  {"{"} Credits : </div>
                                    <span>{credits} {"}"}</span>
                </div>
         </td>
         <td className="thumb-checkbox-wrap">
                        {onHover || true ? <OnHoverOption credit={credit} creditlimit={creditlimit} newselctionref={newselctionref}
                        select={select} forceRerender={forceRerender} credits={credits} info={e} uid={k} src={src} 
                        ability={ability} id={id} toggle={toggle} modal={modal} fibName={''} /> : ''}   
          </td>
         </tr>
        )
    }

//! Looping IMG-Box
const ImgLooped = ({ ability, toggle, modal, imgData, select, forceRerender,  newselctionref, creditlimit, credit }) => {
     return (
        <>
            {

                 imgData.map((e, k) => {

                     return <ImgBox select={select} 
                     e={e} 
                     k={e.td_threed_image_id} 
                     id={e.td_Qv_Image_Configurations_Id ? e.td_Qv_Image_Configurations_Id : e.td_showroom_configuration_id}
                    src={e.tdImages[0].imageUrl} 
                    name={e.tdImages[0].td_threed_image_name}
                    credits={e.tdImages[0].td_credit}
                    Exclusive={e.tdImages[0].is_exclusive}
                    ability={ability} toggle={toggle} modal={modal} 
                    forceRerender={forceRerender} newselctionref={ newselctionref}
                    creditlimit={creditlimit} credit={credit}
                    />
                })
            }
        </>     
    )
}    
//!Image Grid View

       
const ImgGrid = (p) => {
    
    const { imgData, setimgData, setCount, applicationref, modelsref, productsref, orgidref, creditlimit, credit, newcheckedref,
    designameref, txtsearchref, setCredit, setcreditlimit, pagendref, pagestartref, count, forceRerender, newselctionref, activeView, setActiveView} = p
    const [modal, setModal] = useState(false)
    const toggle = () => setModal(!modal)
    const [reloade, setreload] = useState(false)
    const ability = useContext(AbilityContext)
    
    //!Add All State  
    window.getData = () => imgData

        //!Add all view 

     useEffect(async () => {
        console.log({
            orgidref:orgidref.current ? orgidref.current.value : 0,
            application:applicationref.current?.value,
            model:modelsref.current?.selectedIndex,
            products:productsref.current?.value,
            designame:designameref.current?.value,
            textsearch : txtsearchref.current?.value
        })

        const obj = {
            OrganisationId: orgidref.current ? parseInt(orgidref.current.value) : 0,
            Application: applicationref.current?.value,
            ModelState: modelsref.current ? modelsref.current.selectedIndex : 0,
            Product: productsref.current ? productsref.current.value : "All",
            Textsearch: txtsearchref.current ? txtsearchref.current.value : false,
            DesignName: designameref.current?.value,
            start: pagestartref.current,
            end: pagendref.current
        }
        await axios.post(`./ThreeD/ConfigureTdImageSearchByOrgId`, obj).then(res => {
            
            const tempresult = JSON.parse(res.data)           
            setimgData(tempresult.fullViewImageConfigurationDtoList ? tempresult.fullViewImageConfigurationDtoList : tempresult.qvImageConfigurationsDtoList) 
            setCount(tempresult.totalRecords)  
            setCredit(tempresult.totalCredit)  
            setcreditlimit(tempresult.creditLimit)
            })
            console.log(obj)
    return () => {
        setimgData([])
    }
 }, [p.rerender, reloade])

        
    return  (    
        <>
        <div className="position-static ecommerce-application threedthumbview" >
        <Table className=''>
          <thead className={classnames({
                      'grid-view' : activeView === 'grid',
                      'list-view' : activeView === 'list'        
                      })}>
                <tr>
                    
                    <th>Sr. No.</th>
                    <th>Model</th>
                    <th>Name</th>
                    <th>Credits</th>
                    <th>Action</th>
                  
                </tr>
            </thead>
            <tbody className = {classnames({
                'grid-view' : activeView === 'grid',
                'list-view' : activeView === 'list'                                    
                  })}> 
                  <ImgLooped credit={credit} creditlimit={creditlimit} newselctionref={newselctionref}
                        select={p.select} toggle={toggle} modal={modal} imgData={imgData}  ability={ability} forceRerender={forceRerender}
                        newcheckedref={newcheckedref} />
              </tbody> 
                <CustomPagination  pagestartref={pagestartref} pagendref={pagendref} count={count} rerender={setreload} prerender={p.rerender} />
            
            </Table>
          </div>
        </>
    )
}

export default ImgGrid
