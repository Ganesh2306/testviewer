import { Button, Col, Row, Card, CardImg, CardBody, CardText, CardTitle } from 'reactstrap'
import { Link, useHistory } from 'react-router-dom'
import './branding.css'
export const ProductTypeCard = (data) => {
    const history = useHistory()
    return (   
                     <div className='child'>
            <Card className="rounded-0">
                     <Link>
                        <CardImg top src={data.banner} alt='Card cap' />
                    </Link>
                            <CardBody className="text-center">
                    <CardTitle tag='h4'>{data.titleName}</CardTitle>
                    <hr/>
                                <Button.Ripple color='secondary rounded-0' outline onClick={() => history.push('/design')}>
                                View
                                </Button.Ripple>
                            </CardBody>
                        </Card>
                    </div>
                   
    )
}