
import React, { useState } from 'react'
import * as yup from 'yup'
import Swal from 'sweetalert2'
import withReactContent from 'sweetalert2-react-content'
import { useDispatch, useSelector } from 'react-redux'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'

import { Button, Modal, Form } from 'reactstrap'
import ModalHeaderUI from '../../../../modal/ModalHeader'
import ModalFooterUI from '../../../../modal/ModalFooter'
import ModalBodyCollection from '../ModalBodyCollection'
import { propTypes } from 'react-bootstrap/esm/Image'

const MySwal = withReactContent(Swal)

const EditCollection = (props) => {
const [isShow, setShow] = useState(false)   
const [is_open, setis_open] = useState(false)   
const dispatch = useDispatch()

const seasonSchema = yup.object().shape({  
  })
const { register, errors, handleSubmit, trigger } = useForm({ mode: 'onChange', resolver: yupResolver(seasonSchema) })

const onSubmit = () => {    
    setis_open(false)
    return MySwal.fire({
     title: ' Update a Collection?',
      icon: 'success',
      showCancelButton: true,
      confirmButtonText: 'Yes, Update it!',
      customClass: {
        confirmButton: 'btn btn-primary',
        cancelButton: 'btn btn-outline-danger ml-1'
      },
      buttonsStyling: false
    }).then(function (result) {
      if (result.value) {
        MySwal.fire({
          icon: 'success',
          title: 'Collection Updated!',
          text: 'Your file has been assgined in collection.',
          customClass: {
            confirmButton: 'btn btn-success'
          }
        })
      }
    })
  }
  return (
    <div>
        <Modal isOpen={props.isShow2} toggle={() => setis_open(props.setShow2)}  className='modal-sm-12' backdrop={'static'}>
                <ModalHeaderUI setis_open={props.setShow2} headerName="Edit Collection" />
                <Form onSubmit={handleSubmit(onSubmit)}>
                    <ModalBodyCollection bodyFor="Update" register={register} errors={errors}  />
                    <ModalFooterUI FooterBtnName="Update" setis_open={props.setShow2}/>
                </Form>
        </Modal>
    </div>
  )
}

export default EditCollection
