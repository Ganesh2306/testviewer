import { useState, useContext, forwardRef, useEffect } from 'react'
import { Input, Label, Col, ModalBody, FormFeedback, Button } from 'reactstrap'
import DatePicker from "react-datepicker"
import "react-datepicker/dist/react-datepicker.css"
import * as validate from '../../../validation/ValidationFunctions'
import { stateContext } from '../../../context/stateContext'
import Avatar from '@components/avatar'


// ! PopUpBody

const ModalBodyUI = forwardRef((props, ref) => {

    const [img, setImg] = useState(null)
    const renderUserAvatar = () => {
        if (img === null) {
            const stateNum = Math.floor(Math.random() * 6),
                states = ['light-success', 'light-danger', 'light-warning', 'light-info', 'light-primary', 'light-secondary'],
                color = states[stateNum]
            return (
                <Avatar
                    initials
                    color={color}
                    className='rounded mr-2 my-25'
                    content='profile image'
                    contentStyles={{
                        borderRadius: 0,
                        fontSize: 'calc(36px)',
                        width: '100%',
                        height: '100%'
                    }}
                    style={{
                        height: '90px',
                        width: '90px'
                    }}
                />
            )
        } else {
            return (
                <img
                    className='user-avatar rounded mr-2 my-25 cursor-pointer'
                    src={img}
                    alt='user profile avatar'
                    height='90'
                    width='90'
                />
            )
        }
    }
    
    return (
        < ModalBody >
            <Col className="row form-group ">

                <Label className="col-form-label col-sm-6">Season Name <span style={{ color: 'red' }}>*</span></Label>
                <div className="col-sm-6 p-0">
                    <Input autoComplete="off" type="hidden" id="role_Id" 
                         name="role_Id"  />
                     <FormFeedback></FormFeedback>
                    <Input  innerRef={props.register} 
                         name="Season_Name" autoComplete="off" type="text" className="form-control" id="Season Name" placeholder="Season Name"
                     
                    />
                    
                </div>
            </Col>
            <Col className="row form-group ">

                <Label className="col-form-label col-sm-6">Description <span style={{ color: 'red' }}>*</span></Label>
                <div className="col-sm-6 p-0">
                    <Input  autoComplete="off" type="hidden" id="role_Id" 
                         name="Description_id"  />
                     <FormFeedback></FormFeedback>
                    <Input  innerRef={props.register}
                         name="Description" autoComplete="off" type="textarea" className="form-control" id="Description_id" placeholder="Description "
                    />
                    
                </div>
            </Col>
            <Col className="row form-group ">

                <Label className="col-form-label col-sm-6">State <span style={{ color: 'red' }}>*</span></Label>
                <div className="col-sm-6 p-0">
                <Input type="select" name="State" className=" col-sm-12" parentid="#C_StoreType" subid="#C_StoreType" id="C_StoreType"
                    innerRef={props.register} 
                  >
                     <option value="1" name="local">Active</option> 
                     <option value="0" name="local">Block</option> 
                  </Input>
                        
                   
                </div>
            </Col>
            <Col className="row form-group ">

                <Label className="col-form-label col-sm-6">Picture </Label>
                <div className="col-sm-6 p-0">
                     {renderUserAvatar()}
                    <Input innerRef={props.register} autoComplete="off" type="file"  style={{display:'Browse...'}} id="role_Id" 
                         name="profile_Image" placeholder="Description"  />
    
                     <FormFeedback></FormFeedback>
                    
                </div>
            </Col>
        </ModalBody >
    )
})

export default ModalBodyUI
