import axios from 'axios'
import { getCollectionList, getEditSeasonList, GetSeasonMastersList  } from '../../../MethodList'
// ** Get table Data
export const getData = params => {
  return async dispatch => {
    await axios.get('./api/datatables/data', params).then(response => {
      console.log(params)
      dispatch({
        type: 'GET_DATA',
        allData: response.data.allData,
        data: response.data.invoices,
        totalPages: response.data.total,
        params
      })
    })
  }
}
export const getSeasonDataSearch = params => {
  const obj = new Object()
  obj.searchString = params.searchvale
  obj.Start = params.page
  obj.End = params.perPage
  return async dispatch => {
      await axios.post('./Role/SearchRoles', obj).then(response => {
          console.log(params)
          dispatch({
              type: 'GET_DATA',
              data: response.data.allRolesList,
              totalPages: response.data.totalCount
          })
      })
  }
}


export const getEditSeason = season => {
    
    return (dispatch, getState) => {
        axios
        
             .post(`${getEditSeasonList}`, season)
            .then(response => {
                
                dispatch({
                    type: 'GET_SEASON',
                    selectedCustomer: response.data
                })

            })
            .then(() => {

            })
            .catch(err => console.log(err))
    }
}

export const getdeleteSeason = season => {
  return (dispatch, getState) => {
      axios
          .post(`./Season/GetDeleteSeason`, season)
          .then(response => {
              dispatch(getData())
          })
          .then(() => {

          })
          .catch(err => console.log(err))
  }
}

export const getCollection = user => {
      return (dispatch, getState) => {
      axios
          .post(`${getCollectionList}`, user)
          .then(response => {
              
              dispatch({
                  type: 'GET_USER',
                  selectedCustomer: response.data
              })

          })
          .then(() => {

          })
          .catch(err => console.log(err))
  }
}

export const CollezioniGetSeasonMastersList = params => {
  const obj = new Object()
  obj.Start = 0
  obj.End = 7
  //obj.SupplierId = params.SupplierId
  //obj.OrganisationId = params.OrganisationId
  return async dispatch => {
      await axios.post(`./Seasonal/GetSeasonMastersList`, obj).then(response => {
        debugger
          dispatch({
              type: 'get_CollezioniGetSeasonMastersList',
              data: response.data.seasonMastersList,
              totalPages: response.data.totalCount
          })
      })
  }
}

export const CollezioniSearchSeasonMastersList = params => {
  const obj = new Object()
    obj.searchString = params.searchvale
    obj.Start = params.page
    obj.End = params.perPage
  return async dispatch => {
      await axios.post(`./Seasonal/CollezioniSearchSeasonMastersList?SearchString=${obj.searchString}`).then(response => {
        debugger
          dispatch({
              type: 'get_CollezioniGetSeasonMastersList',
              data: response.data.seasonMastersList,
              totalPages: response.data.totalCount
          })
      })
  }
}

