import { CardTitle } from 'reactstrap'

 export const BrandTitle = () => {
    return (      
        <div className="mt-2 title_box ">        
            <CardTitle tag='h3' className='title_a font-weight-bold mb-1 text-lg-center login-header text-center text-black' >
                Select Category
            </CardTitle>
            {/*<CardTitle tag='h3' className='title_b font-weight-bold mb-1 text-lg-center login-header text-center'>*/}
            {/*     YOU WILL LOVE IT*/}
            {/*</CardTitle>*/}
        </div>        
    )
}