import { useState, useContext, createContext } from "react"
import {
    Row,
    Col,
    Input,
    Button,
    Card,
    CardBody,
    CardHeader,
    CardTitle,
    Label,
    InputGroup,
    InputGroupAddon,
    InputGroupText,
    ButtonGroup
} from "reactstrap"
import { List, Grid } from 'react-feather'
import ThreeD_Design from "./popup/ThreeD_Design"
import { AbilityContext } from '@src/utility/context/Can'
import { SaveConfigToArr, rmAllSaveConfig, SetAll} from './ImgGrid'
import axios from 'axios'
import classnames from 'classnames'
import { Dropdown } from "primereact/dropdown"
import { object } from "prop-types"
import MultiSelectProduct from "./MultiselectProduct"
//!Top-Left
const LeftTop = ({ pageRest, forceRerender, ability, PrOrList, applicationref, modelsref, 
    productsref, orgidref, showTdsConfiguration, multiSlectReset }) => {
    return (
        <Col className="col-xl-6 col-lg-6 col-md-12 col-sm-12 d-flex pr-0  col ">
           {/* <form class="form-inline mb-1 flex-nowrap">*/}
                {/*{ ability.can('Display', '3DImages') && <span className="float-left mr-1 ml-1">Orgnization</span> }*/}
            {ability.can('Display', '3DImages') && <> <form class="form-inline flex-wrap select col-md-3 col-sm-12 pl-0 pr-50"> <span className="float-left mr-1">Orgnization</span> <select
                    id="collection3DLibrary"
                    className="form-control float-left mr-1"
                    ref={orgidref}
                    onChange={() => {
                        pageRest()
                        forceRerender() 
                    }}
                >    
                    {
                        PrOrList?.OrgList && Object.keys(PrOrList?.OrgList).map((e, k) => {
                           
                            return <option value={e}>{PrOrList.OrgList[e]}</option>
                            
                        })}
            </select>
            </form> </>
                }
           <form class="form-inline flex-wrap select col-md-3 col-sm-12 pl-0 pr-50">
           <span className="float-left mr-1">Application</span>
           <select
              id="collection3DLibrary"
              className="col-md-12 col-lg-12 col-md-6 col-sm-4 form-control float-left"
              onChange={showTdsConfiguration}
              ref={applicationref}
              >
              <option
                 index="0"                          
                 >
                 Fullview
              </option>
              <option
                 index="1"                          
                 >
                 Showroom
              </option>
                </select>
            </form>
            <form class="form-inline flex-wrap select col-md-3 col-sm-12 pl-0 pr-50">
           <span className="float-left mr-1">Models</span>
           <select
              id="collection3DLibrary"
              className="col-md-12 col-lg-12 col-md-6 col-sm-4 form-control float-left"
              onChange={() => {
                pageRest()
                forceRerender()
              }}
              ref={modelsref}
              >
              <option
              index="0" 
                 >
                 All
              </option>
              <option
                 index="1"                          
                 >
                 Used
              </option>
              <option
                 index="2"                           
                 >
                 NotUsed
                </option>
                {ability.can('configure', '3DImages') && <option
                 index="3"
                 >
                Exclusive
                </option>
                }
                </select>
            </form>

            {/* 
           <select              
                    id="collection3DLibrary"
                    className="form-control float-left"
                >
                    <option
                        index="1"
                    >
                        All
                    </option>
                        {
                        PrOrList?.ProductList.map((e, k) => {
                            return <option value={e}>{e}</option>
                        })}
            </select>  */}
            <form class="form-inline flex-wrap select col-md-3 col-sm-12 pl-0 pr-50">
                <span className="float-left mr-1" style={{ marginBottom: "0.5rem" }}>Product</span>
         {/* <div className="col-md-2 col-lg-2 col-sm-4 float-left pl-0 product_threed">  */}         
             { PrOrList?.ProductList && <MultiSelectProduct  multiSlectReset={multiSlectReset} PrOrList={PrOrList} 
             productsref={productsref} forceRerender={forceRerender} pageRest={pageRest}
              />} 
          
{/*            </div>*/}
            </form>
           {/* <div
           className="col-lg-4 col-sm-4 custom-checkbox float-left" style={{ marginLeft: "6px", marginRight: "6px", float: "left" }} >
           <Input
                        type="checkbox"
                        className="custom-control-input"
                        id="selectAll"
                        onClick={() => setSelect(select => !select)}
              />
           <Label className="custom-control-label" for="selectAll" style={{ marginLeft: "8px", marginRight: "6px", float: "left" }}
           >Select All</Label>
           </div> */}
        {/*</form>*/}
        </Col>
    )
}

//!Top Right
const TopRight = ({modal, toggle, ability, PrOrList, forceRerender, newselctionref, showTdsConfiguration, applicationref }) => {

    const Swal = require('sweetalert2')
    const onSaveConfiguration = (e) => {
        e.preventDefault() 
        console.log(SaveConfigToArr())
        const selection = document.getElementById('collection3DLibrary').value
        //let msg = ""
       
        switch (selection) {
            case 'Showroom':
               
                //msg = selection
                const _RootTdShowroomConfiguration = new Object()

                //const TdShowroomConfigurations = []
                /* const TdShowroomConfiguration = new Object()
                TdShowroomConfiguration.state = 0
                TdShowroomConfiguration.td_Showroom_Configuration_Id = 0
                TdShowroomConfiguration.td_Three_DImage_Id = 19
                TdShowroomConfiguration.td_Organisation_Id = 0
                TdShowroomConfiguration.td_Order_No = 0 */
                //TdShowroomConfigurations.push(TdShowroomConfiguration) 
                _RootTdShowroomConfiguration.td_Showroom_Configurations = SaveConfigToArr()
                axios.post(`./ThreeD/SavehowroomImageConfiguration`, _RootTdShowroomConfiguration)
                    .then(response => {
                        
                        const Isave = response.data === null ? null : JSON.parse(response.data).isSave
                        Swal.fire(
                            'Success!',
                            'Confguration Saved Successfully!!',
                            'success'
                        )
                        forceRerender() 
                        newselctionref.current?.setAttribute('count', 0)
                        newselctionref.current.textContent = `[New selection 0]`
                            const obj = new Object()
                            obj.page = 0
                            obj.perPage = 7
                            dispatch(getData(obj))
                            setis_open(false)
                    })
                    .then(() => {

                    })
                    .catch(err => console.log(err))
                
            default:
                const _RootTdQvImageConfiguration = new Object()

                /* const TdQvImageConfigurations = []
                const TdQvImageConfiguration = new Object()
                TdQvImageConfiguration.state = 0
                TdQvImageConfiguration.td_Qv_Image_Configurations_Id = 0
                TdQvImageConfiguration.td_Threed_Image_Id = 55
                TdQvImageConfiguration.td_Organisation_Id = 0
                TdQvImageConfiguration.td_Order_No = 0
                TdQvImageConfigurations.push(TdQvImageConfiguration) */
                _RootTdQvImageConfiguration.td_Qv_Image_Configurations = SaveConfigToArr()
                axios.post(`./ThreeD/SaveFullViewImageConfiguration`, _RootTdQvImageConfiguration)
                    .then(response => {

                        const Isave = response.data === null ? null : JSON.parse(response.data).isSave
                            //const custuser = new Object()
                            // custuser.customer_Id = response.data.req.org_type_id
                            // dispatch(getCustomerUsers(custuser))
                            //dispatch(getData())
                        Swal.fire(
                            'Success!',
                            'Confguration Saved Successfully!!',
                            'success'
                        )
                        forceRerender()
                        newselctionref.current?.setAttribute('count', 0)
                        newselctionref.current.textContent = `[New selection 0]`
                            const obj = new Object()
                            obj.page = 0
                            obj.perPage = 7
                            dispatch(getData(obj))

                            setis_open(false)
                    })
                    .then(() => {

                    })
                    .catch(err => console.log(err))
                //msg = "XML"
        }
        //alert(msg)
        return

        const _RoleAssignment = new Object()
        _RoleAssignment.user_Id = document.getElementById('CAC_custName').getAttribute('uid')

        _RoleAssignment.is_Role_Admin = true
        _RoleAssignment.role_assignment_id = document.getElementById('CAC_custName').getAttribute('raid') === null ? 0 : document.getElementById('CAC_custName').getAttribute('raid')
        const selectedRoleID = document.getElementById('CAC_accessRole').selectedOptions[0].getAttribute('roleid')
        if (Number(selectedRoleID) === 0) {
            _RoleAssignment.state = 3
        } else {
            _RoleAssignment.state = document.getElementById('CAC_custName').getAttribute('raid') === null ? 0 : 2
        }
        _RoleAssignment.role_Id = selectedRoleID
        //dispatch(addCustUser(custuser))
        axios.post(`./Role/SaveRoleAssignments`, _RoleAssignment)

            .then(response => {

                const Isave = response.data === null ? null : JSON.parse(response.data).isSave
                if (Isave !== null && Isave !== false) {
                    //const custuser = new Object()
                    // custuser.customer_Id = response.data.req.org_type_id
                    // dispatch(getCustomerUsers(custuser))
                    //dispatch(getData())
                    const obj = new Object()
                    obj.page = 0
                    obj.perPage = 7
                    dispatch(getData(obj))

                    setis_open(false)
                    Swal.fire(
                        'Success!',
                        'Role assigned successfully!!',
                        'success'
                    )
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'Something went wrong!'
                    })
                }

            })
            .then(() => {

            })
            .catch(err => console.log(err))
        // console.log(Customer)
    }

    const [Del, setDel] = useState(false)
    const deltoggle = () => setDel(!Del)
    const [Ddata, setData] = useState(null)
    return (
        <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 pr-0" >
            <div className="text-lg-right d-lg-flex" style={{ justifyContent: "right", float: "right" }}>
                <ThreeD_Design PrOrList={PrOrList} modal={modal} toggle={toggle} topbarstate={true} headername = "Add 3D Images" subheadername = "Add and Upload 3D Images" />
              {/* 3d Images part disabled here*/}
                {ability.can('configure', '3DImages') && <Button className="btn btn-sm btn-success mr-1"
                onClick={() => {
                    onSaveConfiguration()                              
                 }} 
                >
                    Save Configuration
                     </Button>}
               
                {ability.can('Display', '3DImages') && <Button
                    type="button"
                    id="add_designBTN"
                    className="btn btn-sm btn-success"
                    onClick={toggle}
                > Add 3D Images
                     </Button>}
               
            </div>
        </div>
    )
}

//!LeftTopDown
 const InputSearchCombo = (props) => {  
    return (
        <>
            <div
                style={{ display: 'block', position: 'relative', float: 'right' }}>
                <InputGroup className='col-12' style={{ marginLeft: "4px" }} >
                  <div class="input-icons"  style={{position:'relative'}}>
                      <Input value={props.tempsearchValue} placeholder="search" className='rounded-left' style={{borderRadius:'0'}}
                       type='text' 
                       onChange={(e) => {
                        props.setTempSearchValue(e.target.value)
                        props.designameref.current = {value:e.target.value}
                     }}   
                     onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                            props.txtsearchref.current = {value:true}
                            props.pageRest() 
                            props.forceRerender()
                        }
                      }}                
                      >                         
                       
                    </Input>
                    <i className="fa fa-times" aria-hidden="true" role='button'   
                    onClick={() => {
                        if (props.tempsearchValue !== '') {
                            props.setTempSearchValue('')
                        props.designameref.current = {value:''}
                        props.txtsearchref.current = {value:false}
                        props.pageRest()
                        props.forceRerender()
                        }
                     }} 
                        style={{position:'absolute', right:'1rem', top:'0.875rem'}}></i>
                  </div>   
                    <InputGroupAddon  addonType="append" className='position-relative'>
                        <InputGroupText className="bg-primary text-white" role="button"   
                        onClick={() => {
                        props.txtsearchref.current = {value:true}
                        props.pageRest()
                        props.forceRerender()
                      }}  
                     >Search

                     </InputGroupText>
                     <Button className="btn btn-sm btn-default ml-50 mr-50" onClick={() => {
                            props.applicationref.current.value = "Fullview"
                            props.showTdsConfiguration()  
                          }} 
                       >
                    Reset
                </Button>
                    </InputGroupAddon>
                </InputGroup>
            </div>
        </>
    )
}

//!TopBar
const TopBarOrg = (props) => {
    const [modal, setModal] = useState(false)
    const toggle = () => setModal(!modal)
    const [advsearch, setadvsearch] = useState(false)
    const ability = useContext(AbilityContext)
    const [multiSlectReset, setmultiSlectReset] = useState(false)
    const [tempsearchValue, setTempSearchValue] = useState('')
    const resetInput = () => {      
        setTempSearchValue('')
    }  
    const showTdsConfiguration = (e) => {
        props.modelsref.current.selectedIndex = 0
        props.txtsearchref.current = {value:false}
        props.newselctionref.current?.setAttribute('count', 0)
        props.newselctionref.current.textContent = `[selection 0]`
        if (tempsearchValue !== '') {
        setTempSearchValue('')
        props.designameref.current = {value:''}
        props.txtsearchref.current = {value:false}
        }
        pageRest()
        rmAllSaveConfig()
        setmultiSlectReset(prv => !prv)
        props.setimgData([])
        props.forceRerender()
    }
    const pageRest = () => {
        props.pagestartref.current = 0
        props.pagendref.current = 25
    }
    
    //console.log(props.PrOrList, 'from TopBarOrg')
    const SearchToggleComponent = (props) => {
        return (
            <>
                <div >
                    { /* className="collapse" */}
                    <div id=""  >
                        <div className="AdvanceSearch">
                            <Col className="col-md-4 col-lg-2 flip mb-8 mb-1" style={{ paddingLeft: "4px", paddingRight: "4px", float: "left" }}>
                                <select
                                    id="Season"
                                    type="text"
                                    className="_featureTypeSearch form-control"
                                    selectcss="0"
                                >
                                    <option className="filter_data">Season</option>
                                </select>
                            </Col>

                            <div className="col-md-4 col-lg-2 flip mb-1" style={{ paddingLeft: "4px", paddingRight: "4px", float: "left" }}>
                                <select
                                    id="Color"
                                    type="text"
                                    className="_featureTypeSearch form-control"
                                    selectcss="1"
                                >
                                    <option className="filter_data">Color</option>
                                </select>
                            </div>
                            <div
                                className="col-md-4 col-lg-2 flip mb-1" style={{ paddingLeft: "4px", paddingRight: "4px", float: "left" }}
                            >
                                <select
                                    id="Pattern"
                                    type="text"
                                    className="_featureTypeSearch form-control"
                                    selectcss="2"
                                >
                                    <option className="filter_data">Pattern</option>
                                </select>
                            </div>
                            <div className="col-md-4 col-lg-2 flip mb-1" style={{ paddingLeft: "4px", paddingRight: "4px", float: "left" }}>
                                <select
                                    id="Weave"
                                    type="text"
                                    className="_featureTypeSearch form-control"
                                    selectcss="3"
                                >
                                    <option className="filter_data">Weave</option>
                                </select>
                            </div>
                         <div className="col-md-4 col-lg-2 d-flex">
                            <button
                                type="button"
                                id="AdvanceSearchBtn"
                                className="btn btn-xs btn-primary waves-effect waves-light mb-2"
                            >
                                Search</button
                            ><button
                                type="button"
                                id="ResetBtn"
                                className="btn btn-xs btn-primary waves-effect waves-light mb-2" style={{ marginLeft: "4px" }}                                    >
                                Reset
                              </button>
                             </div>
                        </div>
                    </div>
                </div>

            </>
        )
    }

    return (
        <>
            <Card className="contain1"> 
            <div className="col-xl-12">
               <CardHeader className='border-bottom'>
                <div className="d-flex">
                        <CardTitle tag='h4' className='d-flex justify-content-start'>3D Images</CardTitle>
                        <div className='creditwallet'>
                        <div className='wallet_title'>Credit Balance</div>
                        <div className='d-flex'>
                         <div className='credit_balance'><span>{props.credit}</span> / <span>{props.creditlimit}</span> <small> Credits</small> </div>
                         <div className='New_Selection' ><span count={0} ref={props.newselctionref} >[selection 0]</span> </div>
                        </div>
                     </div> 
                 </div> 
                 <TopRight PrOrList={props.PrOrList} modal={modal} toggle={toggle} ability={ability} forceRerender={props.forceRerender} 
                 newselctionref={props.newselctionref} pageRest={pageRest} txtsearchref={props.txtsearchref} setimgData={props.setimgData}
                 modelsref={props.modelsref} productsref={props.productsref} applicationref={props.applicationref} 
                 designameref={props.designameref} showTdsConfiguration={showTdsConfiguration} 
                 />              
              
                </CardHeader>
            </div>            
             <CardBody >        
                    <Row className="mb-0">
                        <LeftTop pageRest={pageRest} forceRerender={props.forceRerender} txtsearchref={props.txtsearchref}
                        setimgData={props.setimgData} PrOrList={props.PrOrList} ability={ability} 
                        applicationref={props.applicationref} modelsref={props.modelsref} productsref={props.productsref} 
                        orgidref={props.orgidref} pagestartref={props.pagestartref} pagendref={props.pagendref}
                        newselctionref={props.newselctionref} showTdsConfiguration={showTdsConfiguration}
                        multiSlectReset={multiSlectReset} 
                        />
                                     
                        <div className="col-xl-6 col-xl-6 col-md-12  col-sm-12 d-lg-flex justify-content-end pl-0" style={{ marginTop: "25px" }}>
                            <InputSearchCombo pageRest={pageRest} designameref={props.designameref} tempsearchValue={tempsearchValue}
                             setTempSearchValue={setTempSearchValue} txtsearchref={props.txtsearchref} forceRerender={props.forceRerender}
                             applicationref={props.applicationref} showTdsConfiguration={showTdsConfiguration} />                                       
                            <div className="ml-0 text-lg-right">
                                <div style={{ float: "right", padding: "4px" }}> Total {props.count}</div>
                                <ButtonGroup className='btn-group-toggle'>
                                    <Button
                                        tag='label'
                                        className={classnames('btn-icon view-btn grid-view-btn border-0', {
                                        active: props.activeView === 'grid'
                                        })}
                                        color='primary'
                                        outline
                                        onClick={() => props.setActiveView('grid')}
                                    >
                                        <Grid size={16}  />
                                    </Button>
                                    <Button
                                        tag='label'
                                        className={classnames('btn-icon view-btn list-view-btn', {
                                        active: props.activeView === 'list'
                                        })}
                                        color='primary'
                                        outline
                                        onClick={() => props.setActiveView('list')}
                                    >
                                        <List size={16} />
                                    </Button>
                                </ButtonGroup>
                            </div>
                        </div>
                    </Row>
            </CardBody>
            </Card>
        </>
    )
}

export default TopBarOrg
