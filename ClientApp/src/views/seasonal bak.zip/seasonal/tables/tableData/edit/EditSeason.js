
import React, { useState } from 'react'
import * as yup from 'yup'
import Swal from 'sweetalert2'
import withReactContent from 'sweetalert2-react-content'
import { useDispatch, useSelector } from 'react-redux'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'

import { Button, Modal, Form } from 'reactstrap'
import ModalHeaderUI from '../../../../modal/ModalHeader'
import ModalFooterUI from '../../../../modal/ModalFooter'
import ModalBodyUI from '../../tableData/ModalBodySeason'
import { propTypes } from 'react-bootstrap/esm/Image'

const MySwal = withReactContent(Swal)

const EditSeason = (props) => {
const [isShow, setShow] = useState(false)   
const [is_open, setis_open] = useState(false)   
const dispatch = useDispatch()

const seasonSchema = yup.object().shape({  
  })
const { register, errors, handleSubmit, trigger } = useForm({ mode: 'onChange', resolver: yupResolver(seasonSchema) })

const onSubmit = () => {    
    setis_open(false)
    return MySwal.fire({
     title: ' Update a Season?',
      icon: 'success',
      showCancelButton: true,
      confirmButtonText: 'Yes, Update it!',
      customClass: {
        confirmButton: 'btn btn-primary',
        cancelButton: 'btn btn-outline-danger ml-1'
      },
      buttonsStyling: false
    }).then(function (result) {
      if (result.value) {
        MySwal.fire({
          icon: 'success',
          title: 'Season Created!',
          text: 'Your file has been assgined in season.',
          customClass: {
            confirmButton: 'btn btn-success'
          }
        })
      }
    })
  }
  return (
    <div>
        <Modal isOpen={props.isShow} toggle={() => setis_open(props.setShow)}  className='modal-sm-12' backdrop={'static'}>
                <ModalHeaderUI setis_open={props.setShow} headerName="Edit Season" />
                <Form onSubmit={handleSubmit(onSubmit)}>
                    <ModalBodyUI bodyFor="Update" register={register} errors={errors}  />
                    <ModalFooterUI FooterBtnName="Update" setis_open={props.setShow}/>
                </Form>
        </Modal>
    </div>
  )
}

export default EditSeason
