import ModalHeaderUI from './../modal/ModalHeader'
import ModalFooterUI from './../modal/ModalFooter'
import React, { useState } from 'react'
import * as yup from 'yup'
import Swal from 'sweetalert2'
import withReactContent from 'sweetalert2-react-content'
import { Button, Modal, Form } from 'reactstrap'
import ModalBodyCollection from './tables/tableData/ModalBodyCollection'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'

const MySwal = withReactContent(Swal)

const Addcollection = () => {
    const addcollSchema = yup.object().shape({  
    })
    const { handleSubmit } = useForm({ mode: 'onChange', resolver: yupResolver(addcollSchema) })

    const onSubmit = () => {
        setis_open(false)
        return MySwal.fire({
         title: ' Create a Collection?',
    //     text: "Move designs in Collection?",
          icon: 'success',
          showCancelButton: true,
          confirmButtonText: 'Yes, Create it!',
          customClass: {
            confirmButton: 'btn btn-primary',
            cancelButton: 'btn btn-outline-danger ml-1'
          },
          buttonsStyling: false
        }).then(function (result) {
          if (result.value) {
            MySwal.fire({
              icon: 'success',
              title: 'Collection Created!',
             // text: 'Your file has been assgined in season.',
              customClass: {
                confirmButton: 'btn btn-success'
              }
            })
          }
        })
      }
    

    const [is_open, setis_open] = useState(false)
  return (
    <div>
            <Button.Ripple color='primary' onClick={() => setis_open(true)}>
                Create Collection
           </Button.Ripple>
            <Modal isOpen={is_open} toggle={() => setis_open(false)} className='modal-sm-12' backdrop={'static'}>
                <ModalHeaderUI setis_open={setis_open} headerName="Create Collection" />
                <Form onSubmit={handleSubmit(onSubmit)}>
                    <ModalBodyCollection bodyFor="add"   />
                    <ModalFooterUI setis_open={setis_open} FooterBtnName="Create" />
                </Form>
            </Modal>
        </div>
  )
}

export default Addcollection